<?php
  require_once 'inc/settings.php';
  require_once 'inc/language.php';
  
  include 'inc/svg.php';
  include 'inc/functions/session.php';
  include 'inc/functions/admin/items_approveItem.php';
  include 'inc/functions/admin/items_deleteItem.php';
  include 'inc/functions/admin/categories_deleteCategory.php';
  include 'inc/functions/admin/users_deleteUser.php';
  
  if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] == true && $_SESSION['user_type'] == "admin") { 
?>
<!doctype html>
<html>
  <head>
    <title><?=$website_name;?> - Admin Panel</title>
    <?php include 'inc/templates/header/headerinclude.php';?>
  </head>
  <body id="kt_body" class="header-fixed header-tablet-and-mobile-fixed aside-enabled">
    <div class="d-flex flex-column flex-root">
      <div class="page d-flex flex-row flex-column-fluid">
        <div class="wrapper d-flex flex-column flex-row-fluid" id="kt_wrapper">
          <?php include 'inc/templates/header/header.php';?>
          <div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl mt-5">
            <?php include 'inc/templates/admin/admin_getPanel.php';?>
            <div class="content flex-row-fluid" id="kt_content">
              <div class="row gy-5 g-xl-8">
                <?php
                  if (!$_GET) {
                  	include 'inc/templates/admin/items_getItems.php';
                  	include 'inc/templates/admin/users_getUsers.php';
                  }
                  if (isset($_GET['items'])) { include 'inc/templates/admin/items_getItems.php';}
                  if (isset($_GET['categories'])) { include 'inc/templates/admin/categories_getCategories.php';}
                  if (isset($_GET['add_cat'])) { include 'inc/templates/admin/categories_addCategory.php';}
                  if (isset($_GET['edit_cat'])) { include 'inc/templates/admin/categories_editCategory.php';}
                  if (isset($_GET['users'])) { include 'inc/templates/admin/users_getUsers.php';}
                  if (isset($_GET['add_user'])) { include 'inc/templates/admin/users_addUser.php';}
                  if (isset($_GET['edit_user'])) { include 'inc/templates/admin/users_editUser.php';}
                  if (isset($_GET['logs'])) { include 'inc/templates/admin/logs_getLogs.php';}
                  ?>
              </div>
            </div>
          </div>
          <?php include 'inc/templates/footer/footer.php';?>
        </div>
      </div>
    </div>
    <?php include 'inc/templates/footer/footerinclude.php';?>
	<script>
	$(function() {
	  $('#filter').change(function() {
         this.form.submit();
	  });
	});
	</script>
  </body>
</html>
<?php }
  else {
  $_SESSION["permission_denied"] = "<script>toastr.error('" . lang('permission_denied') . "')</script>";
  header('location: index.php');
  exit(0);
  }
  
?>