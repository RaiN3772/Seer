<?php
  require_once 'inc/settings.php';
  require_once 'inc/language.php';
  
  include 'inc/svg.php'; 
  include 'inc/functions/session.php';
  ?>
<!doctype html>
<html>
  <head>
    <title><?=$website_name;?> - Documentation</title>
    <?php include 'inc/templates/header/headerinclude.php';?>
	<style>
	a {
		color: #3699ff!important;
	}
	</style>
  </head>
  <body id="kt_body" class="header-fixed header-tablet-and-mobile-fixed">
    <div class="d-flex flex-column flex-root">
      <div class="page d-flex flex-row flex-column-fluid">
        <div class="wrapper d-flex flex-column flex-row-fluid" id="kt_wrapper">
          <?php 
		  include 'inc/templates/header/header.php';?>
          <div class="container">
            <div class="row">
              <?php 
			  if (isset($_GET['references'])) { include 'inc/templates/ungrouped/references.php';}
			  if (isset($_GET['files'])) { include 'inc/templates/ungrouped/files.php';}
             
			  ?>
            </div>
          </div>
          <?php include 'inc/templates/footer/footer.php';?>
        </div>
      </div>
    </div>
    <?php include 'inc/templates/footer/footerinclude.php';?>
  </body>
</html>