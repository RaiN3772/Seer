<?php
  require_once 'inc/settings.php';
  require_once 'inc/language.php';
  
  include 'inc/svg.php'; 
  include 'inc/functions/session.php';
  ?>
<!doctype html>
<html>
  <head>
    <title><?=$website_name;?> - Error</title>
    <?php include 'inc/templates/header/headerinclude.php';?>
  </head>
  <body id="kt_body" class="header-fixed header-tablet-and-mobile-fixed">
    <?php 
      if ($active_website == 0) {
      include 'inc/templates/ungrouped/active_website.php';
      }
	  else {
		  header('location: index.php');
		  exit(0);
	  }
      ?>
    <?php include 'inc/templates/footer/footerinclude.php';?>
  </body>
</html>