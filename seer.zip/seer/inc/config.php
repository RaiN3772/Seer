<?php
//ini_set('display_errors', 1);
//error_reporting(E_ALL);
//error_reporting(-1);
//ini_set('error_reporting', E_ALL);

// Database credentials
$db_server = "localhost";
$db_username = "";
$db_password = "";
$db_name = "";

try
{
    // Connect to MYSQL Database using PDO
    $pdo = new PDO("mysql:host={$db_server};dbname={$db_name}", $db_username, $db_password);
    // Set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

}
catch(PDOException $e)
{
    echo "Error: Unable to Connect: " . $e->getMessage();
}


?>
