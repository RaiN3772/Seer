<?php
// Include Database Configuration File
require_once "inc/config.php";
if (isset($_GET['add_cat'])) {
	// Define Variables
	$categoryName = $categoryDescription = NULL;
	$categoryNameError = $categoryDescriptionError = NULL;
	
	// Check whether the form is submitted
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		
		if (empty($_POST["category_name"])) {
			$categoryNameError = "Category Name is Required";
		}
		else {
			$categoryName = secure_input($_POST["category_name"]);
		}
		
		if (empty($_POST["category_description"])) {
			$categoryDescriptionError = "Category Description is Required";
		}
		else {
			$categoryDescription = secure_input($_POST["category_description"]);
		}
		
		if (is_null($categoryNameError) && is_null($categoryDescriptionError)) {
			$sql = $pdo->prepare("INSERT INTO categories (category_name, category_description) VALUES (:category_name, :category_description)");
			$sql->bindParam(':category_name', $categoryName);
			$sql->bindParam(':category_description', $categoryDescription);
			$sql->execute();
			include 'logs/logs_addCategory.php';
			$_SESSION["add_category"] = "<script>toastr.success('" . lang('add__category') . " $categoryName')</script>";
			echo "<script type='text/javascript'>window.location.href = 'admin.php?categories';</script>";
			exit(0);
		}
	}
}

function secure_input($data) {
	trim($data);
	stripslashes($data);
	htmlspecialchars($data);
	  
	return $data;
}
?>
