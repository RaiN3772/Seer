<?php
// Include Database Configuration File
require_once "inc/config.php";
if (isset($_GET['cat_delete'])) {
	
	$delete_id = $_GET['cat_delete'];
	
	$sql = $pdo->prepare("DELETE FROM categories WHERE category_id = :category_id");
	$sql->bindParam(':category_id', $delete_id);
	$sql->execute();
	
	include 'logs/logs_deleteCategory.php';
	
	$_SESSION["delete_category"] = "<script>toastr.warning('" . lang('del__category') . "')</script>";
	header('location: admin.php?categories');
	exit(0);
}

?>