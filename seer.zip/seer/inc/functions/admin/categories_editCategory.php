<?php
// Include Database Configuration File
require_once "inc/config.php";
if (isset($_GET['edit_cat'])) {
	// Define Variables
	$categoryName = $categoryDescription = NULL;
	$categoryNameError = $categoryDescriptionError = NULL;
	
	$log_ip = $_SERVER['REMOTE_ADDR']; # Get client IP Address
	
	$edit_cat = $_GET['edit_cat'];
	
	$sql = $pdo->prepare("SELECT * FROM categories WHERE category_id = :id");
	$sql->bindParam(':id', $edit_cat);
	$sql->execute();
	
	$categories = $sql->fetchAll(PDO::FETCH_ASSOC);
	// Bind Values to variables
	foreach ($categories as $categories) {
		$category_id = $categories["category_id"];
		$category_name = $categories["category_name"];
		$category_description = $categories["category_description"];
	}
	
	
	
	// Check whether the form is submitted
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		
		if (empty($_POST["category_name"])) {
			$categoryNameError = "Category Name is Required";
		}
		else {
			$categoryName = secure_input($_POST["category_name"]);
		}
		
		if (empty($_POST["category_description"])) {
			$categoryDescriptionError = "Category Description is Required";
		}
		else {
			$categoryDescription = secure_input($_POST["category_description"]);
		}
		
		if (is_null($categoryNameError) && is_null($categoryDescriptionError)) {
			$sql = $pdo->prepare("UPDATE categories set category_name = :category_name, category_description = :category_description WHERE category_id = :category_id");
			$sql->bindParam(':category_id', $edit_cat);
			$sql->bindParam(':category_name', $categoryName);
			$sql->bindParam(':category_description', $categoryDescription);
			$sql->execute();
			
			include 'logs/logs_editCategory.php';
			
			$_SESSION["edit_category"] = "<script>toastr.success('" . lang('edit__category') . " $category_name')</script>";
			echo "<script type='text/javascript'>window.location.href = 'admin.php?categories';</script>";
			exit(0);
		}
	}

}

function secure_input($data) {
	trim($data);					// Lets remove whitespace and other predefined characters from both sides of a string
	stripslashes($data);			// Lets remove backslashes
	htmlspecialchars($data);		// Lets convert some predefined characters to HTML entities; No html tags or scripts and sql injection
	  
	return $data;
}
?>
