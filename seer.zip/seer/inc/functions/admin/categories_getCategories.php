<?php
// Include Database Configuration File
require_once "inc/config.php";

if (isset($_GET['categories'])) {

    $sql = "SELECT * FROM categories";
    $statement = $pdo->query($sql);
    $category_counter = $statement->rowCount();
    $categories = $statement->fetchAll(PDO::FETCH_ASSOC);

}

function categories_getCategories() {

    global $categories;

    foreach ($categories as $categories) {
        echo "<tr>";

        echo "<td>";
        echo "<div class='d-flex align-items-center'>";
        echo "<div class='symbol symbol-50px me-5'>";
        echo "<div class='symbol-label'>";
        echo svg('category_icon');
        echo "</div>";
        echo "</div>";
        echo "<div class='d-flex justify-content-start flex-column'>";
        echo "<a class='text-dark fw-bolder text-hover-primary fs-6'>" . $categories["category_name"] . "</a>";
        echo "</div>";
        echo "</div>";
        echo "</td>";

        echo "<td><span class='text-muted fw-bold text-muted d-block fs-7'>" . $categories["category_id"] . "</span></td>";
        echo "<td><span class='badge badge-info'>" . $categories["category_description"] . "</span></td>";

        echo "<td>";
        echo "<div class='d-flex justify-content-end flex-shrink-0'>";
        echo "<a href='?edit_cat=" . $categories["category_id"] . "' class='btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1'><span class='svg-icon svg-icon-3'>" . svg('item_edit') . "</span></a>";

        echo "<a href='?cat_delete=" . $categories["category_id"] . "' class='btn btn-icon btn-bg-light btn-active-color-primary btn-sm'><span class='svg-icon svg-icon-3'>" . svg('item_delete') . "</span></a>";
        echo "</div>";
        echo "</td>";

        echo "<tr>";

    }
	
    $pdo = null; // Close PDO Connection
    
}

?>
