<?php
// Include Database Configuration File
require_once "inc/config.php";
if (isset($_GET['item_approve'])) {
	
	$approve_id = $_GET['item_approve'];
	
	$sql = $pdo->prepare("UPDATE items SET item_status = 'Approved' WHERE item_id = :item_id");
	$sql->bindParam(':item_id', $approve_id);
	$sql->execute();
	include 'logs/logs_approveItem.php';
	$_SESSION["delete_item"] = "<script>toastr.info('" . lang('approve__item') . "')</script>";
	header('location: admin.php?items');
	exit(0);
}

?>