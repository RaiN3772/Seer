<?php
// Include Database Configuration File
require_once "inc/config.php";

if (isset($_GET['item_delete'])) {
	
	$delete_id = $_GET['item_delete'];
	
	$sql = $pdo->prepare("DELETE FROM items WHERE item_id = :item_id");
	$sql->bindParam(':item_id', $delete_id);
	$sql->execute();
	include 'logs/logs_deleteItem.php';
	$_SESSION["delete_item"] = "<script>toastr.warning('" . lang('del__item') . "')</script>";
	header('location: admin.php?items');
	exit(0);
}

?>