<?php
// Include Database Configuration File
require_once "inc/config.php";

if (!empty($_GET['items']) == "unapproved") {
    $sql = "SELECT * FROM items INNER JOIN users ON items.uid = users.uid inner Join categories ON items.category_id = categories.category_id WHERE item_status = 'Unapproved'";
    $statement = $pdo->query($sql);
    $item_counter = $statement->rowCount();
}
else {
    $sql = "SELECT * FROM items INNER JOIN users ON items.uid = users.uid inner Join categories ON items.category_id = categories.category_id";
    $statement = $pdo->query($sql);
    $item_counter = $statement->rowCount();
}

$items = $statement->fetchAll(PDO::FETCH_ASSOC);

function items_getItems() {

    global $items;

    foreach ($items as $items) {

        echo "<tr>";

        echo "<td>";
        echo "<div class='d-flex align-items-center'>";
        echo "<div class='symbol symbol-45px me-5'>";
        echo "<img src='" . $items["item_thumbnail"] . "'>";
        echo "</div>";
        echo "<div class='d-flex justify-content-start flex-column'>";
        echo "<a href='item.php?id=" . $items["item_id"] . "' class='text-dark fw-bolder text-hover-primary fs-6'>" . $items["item_name"] . "</a>";
        echo "<span class='text-muted fw-bold text-muted d-block fs-7'>" . $items["item_short_description"] . "</span>";
        echo "</div>";
        echo "</div>";
        echo "</td>";

        echo "<td><span class='text-muted fw-bold text-muted d-block fs-7'>" . $items["username"] . "</span></td>";
        echo "<td><span class='badge badge-warning'>" . $items["category_name"] . "</span></td>";
        if ($items["item_status"] == "Approved")
        {
            echo "<td><span class='badge badge-success'>" . $items["item_status"] . "</span></td>";
        }
        if ($items["item_status"] == "Unapproved")
        {
            echo "<td><span class='badge badge-danger'>" . $items["item_status"] . "</span></td>";
        }
        echo "<td>";
        echo "<div class='d-flex justify-content-end flex-shrink-0'>";
        if ($items["item_status"] == "Unapproved")
        {
            echo "<a href='?item_approve=" . $items["item_id"] . "' class='btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1' title='Approve Item' data-bs-toggle='tooltip' data-bs-trigger='hover'><span class='svg-icon svg-icon-3'>" . svg('item_approve') . "</span></a>";
        }
        else
        {
            echo "<a href='item.php?edit=" . $items["item_id"] . "' class='btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1'><span class='svg-icon svg-icon-3'>" . svg('item_edit') . "</span></a>";
        }
        echo "<a href='?item_delete=" . $items["item_id"] . "' class='btn btn-icon btn-bg-light btn-active-color-primary btn-sm'><span class='svg-icon svg-icon-3'>" . svg('item_delete') . "</span></a>";
        echo "</div>";
        echo "</td>";

        echo "<tr>";

    }
    $pdo = null; // Close PDO Connection
    
}

?>
