<?php
$log_ip = $_SERVER['REMOTE_ADDR']; # Get client IP Address
$sql = $pdo->prepare("INSERT INTO logs (log_uid, log_action, log_ip, log_information, log_type) VALUES (:log_uid, :log_action, :log_ip, :log_information, :log_type)");
$log_type = "users";
$log_action = "Deleted User";
$log_information = "User ID: " . $delete_id;


$sql->bindParam(':log_uid', $uid);
$sql->bindParam(':log_action', $log_action);
$sql->bindParam(':log_ip', $log_ip);
$sql->bindParam(':log_information', $log_information);
$sql->bindParam(':log_type', $log_type);

$sql->execute();

?>
