<?php
$sql = $pdo->prepare("INSERT INTO logs (log_uid, log_action, log_ip, log_information, log_type) VALUES (:log_uid, :log_action, :log_ip, :log_information, :log_type)");
$log_type = "categories";
$log_action = "Edited Category";
$sql->bindParam(':log_type', $log_type);
if ($category_name != $categoryName) {
    $log_information = "Category Name: \"" . $category_name . "\" to \"" . $categoryName . "\"";
}
elseif ($category_description != $categoryDescription) {
    $log_information = "Category Description: \"" . $category_description . "\" to \"" . $categoryDescription . "\"";
}
else {
    $log_information = "Category ID: " . $category_id;
}


$sql->bindParam(':log_uid', $uid);
$sql->bindParam(':log_action', $log_action);
$sql->bindParam(':log_ip', $log_ip);
$sql->bindParam(':log_information', $log_information);
$sql->execute();

?>
