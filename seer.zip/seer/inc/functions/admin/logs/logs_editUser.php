<?php
$log_ip = $_SERVER['REMOTE_ADDR']; # Get client IP Address
$sql = $pdo->prepare("INSERT INTO logs (log_uid, log_action, log_ip, log_information, log_type) VALUES (:log_uid, :log_action, :log_ip, :log_information, :log_type)");
$log_type = "users";
$log_action = "Edited User";

if ($user_username != $username) {
    $log_information = "Username: \"" . $user_username . "\" to \"" . $username . "\", User: " . $user_username;
}
elseif ($user_title != $userTitle) {
    $log_information = "User Title: \"" . $user_title . "\" to \"" . $userTitle . "\", User: " . $user_username;
}
elseif ($user_email != $email) {
    $log_information = "User Email: \"" . $user_email . "\" to \"" . $email . "\", User: " . $user_username;
}
elseif ($user_type != $userType) {
    $log_information = "User Type: \"" . $user_type . "\" to \"" . $userType . "\", User: " . $user_username;
}
elseif (!empty($_POST["password"])) {
	$log_information = "Changed Password, User: " . $user_username;
}
else {
    $log_information = "User ID: " . $edit_user . ", User: " . $user_username;
}

$sql->bindParam(':log_uid', $uid);
$sql->bindParam(':log_action', $log_action);
$sql->bindParam(':log_ip', $log_ip);
$sql->bindParam(':log_information', $log_information);
$sql->bindParam(':log_type', $log_type);
$sql->execute();

?>
