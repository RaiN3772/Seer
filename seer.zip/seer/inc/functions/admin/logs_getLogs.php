<?php
// Include Database Configuration File
require_once "inc/config.php";

if (isset($_GET['logs'])) {
	
	$filter = NULL;
	
	if(isset($_POST['filter'])){
		$filter = $_POST['filter'];
		$sql = $pdo->prepare("SELECT * FROM logs INNER JOIN users ON logs.log_uid = users.uid WHERE log_type = :filter ORDER BY log_date DESC");
		$sql->bindParam(':filter', $filter);
		$sql->execute();
		$log_counter = $sql->rowCount();
		$logs = $sql->fetchAll(PDO::FETCH_ASSOC);
	}
	else {
		$sql = "SELECT * FROM logs INNER JOIN users ON logs.log_uid = users.uid ORDER BY log_date DESC";
		$statement = $pdo->query($sql);
		$log_counter = $statement->rowCount();
		$logs = $statement->fetchAll(PDO::FETCH_ASSOC);
	}
}

function logs_getLogs() {

    global $logs;

    foreach ($logs as $logs) {
        echo "<tr>";
		
		echo "<td>" . $logs['username'] . "</td>";
		echo "<td>" . $logs['log_action'] . "</td>";
		echo "<td>" . $logs['log_information'] . "</td>";
		echo "<td>" . $logs['log_ip'] . "</td>";
		echo "<td>" . $logs['log_date'] . "</td>";
		
        echo "<tr>";

    }
	
    $pdo = null; // Close PDO Connection
    
}

?>
