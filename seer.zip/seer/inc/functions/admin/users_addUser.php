<?php
// Include Database Configuration File
require_once "inc/config.php";

if (isset($_GET['add_user'])) {

    // Define variables and initialize with empty values
    $username = $password = $confirmPassword = $email = $userType = NULL;
    $usernameError = $passwordError = $confirmPasswordError = $emailError = $userTypeError = $generalError = NULL;

    // Check whether the form is submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        if (empty($_POST["username"])) {
            $usernameError = "Username is required";
        }
        elseif (strlen($_POST["username"]) < $username_min_length) {
            $usernameError = "Username must have atleast " . $username_min_length . " charecters";
        }
        else {
            $username = secure_input($_POST["username"]);

            $sql = $pdo->prepare("SELECT * FROM users WHERE username = :username");
            $sql->bindParam(':username', $username);
            $sql->execute();

            if ($sql->rowCount() > 0) {
                $usernameError = "This username is already taken.";
                $username = NULL;
            }

        }

        if (empty($_POST["email"])) {
            $emailError = "Email is required";
        }
        else {
            $email = secure_input($_POST["email"]);

            if (filter_var($email, FILTER_VALIDATE_EMAIL)) {

                $sql = $pdo->prepare("SELECT * FROM users WHERE email = :email");
                $sql->bindParam(':email', $email);;
                $sql->execute();
				
                if ($sql->rowCount() > 0) {
                    $emailError = "This Email is already taken.";
                    $email = NULL;
                }
            }
            else {
                $emailError = "Invalid Email Address";
            }
        }

        if (empty($_POST["password"])) {
            $passwordError = "Please Enter a Password";
        }
        elseif (strlen($_POST["password"]) < $password_min_length) {
            $passwordError = "Password must have atleast " . $password_min_length . " charecters";
        }
        else {
            $password = secure_input($_POST["password"]);
        }

        if (empty($_POST['confirmPassword'])) {
            $confirmPasswordError = "Please confirm the Password";
        }
        else {
            $confirmPassword = secure_input($_POST['confirmPassword']);
            if (is_null($passwordError) && ($password != $confirmPassword)) {
                $confirmPasswordError = "Password did not match";
            }
        }

        if (empty($_POST["userType"])) {
            $userTypeError = "User Type is Required";
        }
        else {
            $userType = secure_input($_POST["userType"]);
        }

        if (is_null($usernameError) && is_null($passwordError) && is_null($confirmPasswordError) && is_null($emailError) && is_null($userTypeError)) {
			
            $sql = $pdo->prepare("INSERT INTO users (username, email, password, user_type) VALUES (:username, :email, :password, :user_type)");
			
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            $sql->bindParam(':username', $username);
            $sql->bindParam(':email', $email);
            $sql->bindParam(':password', $hashed_password);
            $sql->bindParam(':user_type', $userType);
            $sql->execute();
			include 'logs/logs_addUser.php';
			$_SESSION["add_user"] = "<script>toastr.success('" . lang('add__user') . " $username')</script>";
            echo "<script type='text/javascript'>window.location.href = 'admin.php?users';</script>";
			exit(0);

        }

    }

}

function secure_input($data) {
    trim($data);
    stripslashes($data);
    htmlspecialchars($data);
    return $data;
}
?>
