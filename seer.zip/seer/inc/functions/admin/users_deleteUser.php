<?php
// Include Database Configuration File
require_once "inc/config.php";
if (isset($_GET['user_delete'])) {
	
	$delete_id = $_GET['user_delete'];
	
	$sql = $pdo->prepare("SELECT * FROM users WHERE uid = :uid LIMIT 1");
	$sql->bindParam(':uid', $delete_id);
	$sql->execute();
	$user = $sql->fetchAll(PDO::FETCH_ASSOC);
	foreach ($user as $user) {
		$user_del_id = $user["uid"];
		$user_del_username = $user["username"];
		$user_del_usertype = $user["user_type"];
	}
	if ($user_del_usertype == "admin") {
		$_SESSION["delete_user"] = "<script>toastr.error('Sorry, but you cannot delete $user_del_username, Because they are an Administrator')</script>";
		header('location: admin.php?users');
		exit(0);
	}
	else {
	$sql = $pdo->prepare("DELETE FROM users WHERE uid = :userid");
	$sql->bindParam(':userid', $delete_id);
	$sql->execute();
	include 'logs/logs_deleteUser.php';
	$_SESSION["delete_user"] = "<script>toastr.warning('" . lang('del__user') . " $user_del_username')</script>";
	header('location: admin.php?users');
	exit(0);
	}
}

?>