<?php
// Include Database Configuration File
require_once "inc/config.php";

if (isset($_GET['edit_user'])) {

    $edit_user = $_GET['edit_user'];

    $sql = $pdo->prepare("SELECT * FROM users WHERE uid = :id");
    $sql->bindParam(':id', $edit_user);
    $sql->execute();

    $users = $sql->fetchAll(PDO::FETCH_ASSOC);
    // Bind Values to variables
    foreach ($users as $users) {
        $user_id = $users["uid"];
        $user_username = $users["username"];
        $user_email = $users["email"];
        $user_avatar = $users["user_avatar"];
        $user_type = $users["user_type"];
        $user_title = $users["user_title"];
    }

    // Define variables and initialize with empty values
    $username = $password = $confirmPassword = $email = $userType = $userTitle = NULL;
    $usernameError = $passwordError = $confirmPasswordError = $emailError = $userTypeError = $userTitleError = $generalError = NULL;

    // Check whether the form is submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        if (empty($_POST["username"])) {
            $usernameError = "Username is required";
        }
        elseif (strlen($_POST["username"]) < $username_min_length) {
            $usernameError = "Username must have atleast " . $username_min_length . " charecters";
        }
        else {
            $username = secure_input($_POST["username"]);

            $sql = $pdo->prepare("SELECT * FROM users WHERE username = :username");
            $sql->bindParam(':username', $username);

            if ($username != $user_username) {
				
                $sql->execute();

                if ($sql->rowCount() > 0) {
                    $usernameError = "This username is already taken.";
                    $username = NULL;
                }
            }
        }

        if (empty($_POST["email"])) {
            $emailError = "Email is required";
        }
        else {
            $email = secure_input($_POST["email"]);

            if (filter_var($email, FILTER_VALIDATE_EMAIL)) {

                $sql = $pdo->prepare("SELECT * FROM users WHERE email = :email");
                $sql->bindParam(':email', $email);

                if ($email != $user_email) {
					
                    $sql->execute();

                    if ($sql->rowCount() > 0) {
                        $emailError = "This Email is already taken.";
                        $email = NULL;
                    }
                }
            }
            else {
                $emailError = "Invalid Email Address";
            }

        }

        if (!empty($_POST["password"]) && (strlen($_POST["password"]) < $password_min_length)) {
            $passwordError = "Password must have atleast " . $password_min_length . " charecters";
        }
        elseif (!empty($_POST["password"])) {
            $password = secure_input($_POST["password"]);
        }

        if (!empty($_POST['confirmPassword'])) {
            $confirmPassword = secure_input($_POST['confirmPassword']);
            if (is_null($passwordError) && ($password != $confirmPassword)) {
                $confirmPasswordError = "Password did not match";
            }
        }

        if (empty($_POST["userType"])) {
            $userTypeError = "User Type is Required";
        }
        else {
            $userType = secure_input($_POST["userType"]);
        }
        if (empty($_POST["usertitle"])) {
            $userTitle = "Default Title";
        }
        elseif (strlen($_POST["usertitle"]) > $usertitle_max_length) {
            $userTitleError = "User Title must be below " . $usertitle_max_length . " charecters";
        }
        else {
            $userTitle = secure_input($_POST["usertitle"]);
        }

        if (is_null($usernameError) && is_null($passwordError) && is_null($confirmPasswordError) && is_null($emailError) && is_null($userTypeError) && is_null($userTitleError)) {

            if (!empty($_POST["password"]) && (!empty($_POST['confirmPassword']))) {
				
                $sql = $pdo->prepare("UPDATE users set username = :username, email = :email, password = :password, user_type = :user_type, user_title = :user_title WHERE uid = :userid");

                $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                $sql->bindParam(':username', $username);
                $sql->bindParam(':userid', $edit_user);
                $sql->bindParam(':email', $email);
                $sql->bindParam(':password', $hashed_password);
                $sql->bindParam(':user_type', $userType);
                $sql->bindParam(':user_title', $userTitle);
                $sql->execute();
				include 'logs/logs_editUser.php';
				if ($user_username == $_SESSION['username']) {
					$_SESSION['user_title'] = $userTitle;
				}
				$_SESSION["edit_user"] = "<script>toastr.success('" . lang('edit__user') . " $username')</script>";
                echo "<script type='text/javascript'>window.location.href = 'admin.php?users';</script>";
				exit(0);
            }
            elseif (empty($_POST["password"]) && (empty($_POST['confirmPassword']))) {

                $sql = $pdo->prepare("UPDATE users set username = :username, email = :email, user_type = :user_type, user_title = :user_title WHERE uid = :userid");

                $sql->bindParam(':username', $username);
                $sql->bindParam(':userid', $edit_user);
                $sql->bindParam(':email', $email);
                $sql->bindParam(':user_type', $userType);
                $sql->bindParam(':user_title', $userTitle);
                $sql->execute();
				include 'logs/logs_editUser.php';
				if ($user_username == $_SESSION['username']) {
					$_SESSION['user_title'] = $userTitle;
				}
				$_SESSION["edit_user"] = "<script>toastr.success('" . lang('edit__user') . " $username')</script>";
                echo "<script type='text/javascript'>window.location.href = 'admin.php?users';</script>";
				exit(0);
            }
            else{
				$_SESSION["general_error"] = "<script>toastr.error('" . lang('general_error') . " [users_editUser]')</script>";
            }
        }
    }
}

function secure_input($data) {
    trim($data);
    stripslashes($data);
    htmlspecialchars($data);

    return $data;
}
?>
