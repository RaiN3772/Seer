<?php
// Include Database Configuration File
require_once "inc/config.php";

$sql = "SELECT * FROM users";
$statement = $pdo->query($sql);
$user_counter = $statement->rowCount();

$users = $statement->fetchAll(PDO::FETCH_ASSOC);

function users_getUsers() {

    global $users;

    foreach ($users as $users) {

        echo "<tr>";

        echo "<td>";
        echo "<div class='d-flex align-items-center'>";
        echo "<div class='symbol symbol-45px me-5'>";
        echo "<img src='" . $users["user_avatar"] . "'>";
        echo "</div>";
        echo "<div class='d-flex justify-content-start flex-column'>";
        echo "<a href='profile.php?id=" . $users["uid"] . "' class='text-dark fw-bolder text-hover-primary fs-6'>" . $users["username"] . "</a>";
        echo "<span class='text-muted fw-bold text-muted d-block fs-7'>" . $users["user_title"] . "</span>";
        echo "</div>";
        echo "</div>";
        echo "</td>";

        echo "<td><span class='text-muted fw-bold text-muted d-block fs-7'>" . $users["uid"] . "</span></td>";
        if ($users["user_type"] == "admin") {
            echo "<td><span class='text-muted fw-bold text-muted d-block fs-7'>Administrator</span></td>";
        }
        else {
            echo "<td><span class='text-muted fw-bold text-muted d-block fs-7'>User</span></td>";
        }
        echo "<td><span class='text-muted fw-bold text-muted d-block fs-7'>" . $users["email"] . "</span></td>";
        echo "<td><span class='text-muted fw-bold text-muted d-block fs-7'>" . $users["created_at"] . "</span></td>";

        echo "<td>";
        echo "<div class='d-flex justify-content-end flex-shrink-0'>";
        echo "<a href='?edit_user=" . $users["uid"] . "' class='btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1' title='Edit User' data-bs-toggle='tooltip' data-bs-trigger='hover'><span class='svg-icon svg-icon-3'>" . svg('item_edit') . "</span></a>";
        echo "<a href='?user_delete=" . $users["uid"] . "' class='btn btn-icon btn-bg-light btn-active-color-primary btn-sm' title='Delete User' data-bs-toggle='tooltip' data-bs-trigger='hover'><span class='svg-icon svg-icon-3'>" . svg('item_delete') . "</span></a>";
        echo "</div>";
        echo "</td>";

        echo "<tr>";

    }
    $pdo = null; // Close PDO Connection
    

    
}

?>
