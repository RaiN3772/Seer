<?php
// Quick Mode Select
$mode_time = time() + (86400 * 30); // Set User mode's choice to 30 days, 86400 = 1 day (Default: 30 Days)
if (!isset($_COOKIE['mode'])) {
    $mode = "light";
    setcookie("mode", $mode, $mode_time);
}
if (isset($_COOKIE['mode'])) {
    $mode = $_COOKIE['mode'];
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['mode'])) {
    if (!empty($_POST['mode']) && $_POST['mode'] == "light") {
        $mode = "light";
        setcookie("mode", "light", $mode_time);
    }
    elseif (!empty($_POST['mode']) && $_POST['mode'] == "dark") {
        $mode = "dark";
        setcookie("mode", "dark", $mode_time);
    }
    else {
        $mode = "light";
        setcookie("mode", "light", $mode_time);
    }
	header("Refresh:0");
}

?>
