<?php
// Include Database Configuration File
require_once "inc/config.php";

// Select Statement
$sql = "SELECT * FROM categories";
$statement = $pdo->query($sql);

// Get all Categories as associative array
$header_categories = $statement->fetchAll(PDO::FETCH_ASSOC);

function header_getCategories() {
	
    global $header_categories;

    foreach ($header_categories as $categories) {

        echo "<div class='menu-item'>";
        echo "<a class='menu-link py-3' href='items.php?cat_id=" . $categories["category_id"] . "' title='" . $categories["category_description"] . "' data-bs-toggle='tooltip' data-bs-trigger='hover' data-bs-dismiss='click' data-bs-placement='right'>";
        echo "<span class='menu-icon'>";
        echo "<span class='svg-icon svg-icon-2'>";
        echo svg('category_icon');
        echo "</span>";
        echo "</span>";
        echo "<span class='menu-title'>" . $categories["category_name"] . "</span>";
        echo "</a>";
        echo "</div>";
    }

    $pdo = null; // Close PDO Connection
    
}

?>
