<?php

// Include Database Configuration File
require_once "inc/config.php";

// Define variables and initialize with empty values
$itemName = $itemPrice = $itemShortDescription = $itemDescription = $itemThumbnail = $itemFeatures = $itemRequirements = $itemCategory = $itemFile = NULL;
$itemNameError = $itemPriceError = $itemShortDescriptionError = $itemDescriptionError = $itemThumbnailError = $itemCategoryError = $itemFileError = $generalError = NULL;

// Check whether the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (empty($_POST["item_name"])) {
        $itemNameError = "Item Name is required";
    }
    else {
        $itemName = secure_input($_POST["item_name"]);
    }

    if (empty($_POST["item_short_description"])) {
        $itemShortDescriptionError = "Short Description is required";
    }
    else {
        $itemShortDescription = secure_input($_POST["item_short_description"]);
    }

    if (empty($_POST["item_description"])) {
        $itemDescriptionError = "Item Description is required";
    }
    else {
        $itemDescription = secure_input($_POST["item_description"]);
    }

    if (empty($_POST["item_price"])) {
        $itemPriceError = "Item Price is required";
    }
    else {
        $itemPrice = secure_input($_POST["item_price"]);
    }

    $itemFeatures = secure_input($_POST["item_features"]);
    $itemRequirements = secure_input($_POST["item_requirements"]);

    $edit_item_ip = $_SERVER['REMOTE_ADDR'];
    $approved = "Approved";
    $item_edit_time = date('m/d/Y h:i:s');

    // Check input error before inserting into database
    if (is_null($itemNameError) && is_null($itemPriceError) && is_null($itemThumbnailError) && is_null($itemDescriptionError) && is_null($itemShortDescriptionError) && is_null($itemCategoryError) && is_null($itemFileError)) {

        // Prepare insert statement
        $sql = $pdo->prepare("UPDATE items SET item_name = :item_name, item_short_description = :item_shortdescription, item_description = :item_description, item_features = :item_features, item_requirements = :item_requirements, item_price = :item_price, item_edit_ip = :item_edit_ip,item_edit_time = :item_edit_time WHERE item_id = :edit");

        // Bind parameters
        $sql->bindParam(':item_name', $itemName);
        $sql->bindParam(':item_shortdescription', $itemShortDescription);
        $sql->bindParam(':item_description', $itemDescription);
        $sql->bindParam(':item_features', $itemFeatures);
        $sql->bindParam(':item_requirements', $itemRequirements);
        $sql->bindParam(':item_price', $itemPrice);
        $sql->bindParam(':item_edit_ip', $edit_item_ip);
        $sql->bindParam(':item_edit_time', $item_edit_time);
        $sql->bindParam(':edit', $edit);
        // Attempt to execute
        $sql->execute();
		include 'inc/functions/admin/logs/logs_editItem.php';
		$_SESSION["edit_item"] = "<script>toastr.success('" . lang('edit__item') . " $itemName')</script>";
        // Redirect to Item Page
        echo "<script type='text/javascript'>window.location.href = 'item.php?id=$item_id';</script>";
		exit(0);

        // Close Connection
        $pdo = NULL;

    }
    else {
        $_SESSION["general_error"] = "<script>toastr.error('" . lang('general_error') . " [edit_item]')</script>";
    }

}

function secure_input($data) {
    trim($data);
    stripslashes($data);
    htmlspecialchars($data);
    return $data;
}

