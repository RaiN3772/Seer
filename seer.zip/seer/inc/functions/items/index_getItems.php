<?php
// Include Database Configuration File
require_once "inc/config.php";

// Select Statement
$sql = "SELECT * FROM items inner Join users ON items.uid = users.uid WHERE item_status = 'Approved' LIMIT 6";
$statement = $pdo->query($sql);

// Get all items as associative array
$items = $statement->fetchAll(PDO::FETCH_ASSOC);

function index_getItems() {
    global $items;

    foreach ($items as $items) { 
        echo "<div class='col-lg-4 mt-5'>";
        echo "<div class='card shadow-md'>";
        echo "<div class='card-body p-0 overlay overflow-hidden'>";
        echo "<div class='overlay-wrapper'>";
        echo "<img src='" . $items["item_thumbnail"] . "' class='w-100 rounded'/>";
        echo "<div class='card-img-overlay'><span class='badge badge-success fs-5 fw-bolder my-2'>$" . $items["item_price"] . "</span></div>";
        echo "</div>";
        echo "<div class='overlay-layer bg-dark bg-opacity-25'>";
        echo "<a href='item.php?id=" . $items["item_id"] . "' class='btn btn-primary btn-shadow'>Preview</a>";
        echo "</div>";
        echo "</div>";
        echo "<div class='card-footer'>";
        echo "<h5 class='card-title'>" . $items["item_name"] . "</h5>";
        echo "<a href='profile.php?id=" . $items["uid"] . "' class='card-text mb-2 text-muted'>By " . $items["username"] . "</a>";
        echo "</div>";
        echo "</div>";
        echo "</div>";

    }
    $pdo = null; //close PDO Connection
    
}

?>
