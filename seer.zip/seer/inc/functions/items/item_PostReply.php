<?php

// Include Database Configuration File
require_once "inc/config.php";

// Define variables and initialize with empty values
$reply = NULL;
$replyError = $generalError = NULL;

$reply_ip = $_SERVER['REMOTE_ADDR'];

// Check whether the form is submitted
if (($_SERVER["REQUEST_METHOD"] == "POST") && isset($_POST["reply"])) {

    if (empty($_POST["reply"])) {
        $replyError = "You cannot post an empty reply";
		$_SESSION["reply_post"] = "<script>toastr.error('" . $replyError . "')</script>";
    }
	else {
		$replyError = NULL;
		$reply = secure_reply($_POST["reply"]);
	}


    // Check input error before inserting into database
    if (is_null($replyError)) {
		$feedback_id = $_POST["feedback_reply_id"];
        // Prepare insert statement
        $sql = $pdo->prepare("INSERT INTO replies (feedback_id, uid, item_id, reply_post, reply_ip) VALUES (:feedback_id, :uid, :item_id, :reply_post, :reply_ip)");
		
        // Bind parameters
        $sql->bindParam(':feedback_id', $feedback_id);
        $sql->bindParam(':uid', $uid);
        $sql->bindParam(':item_id', $item_id);
        $sql->bindParam(':reply_post', $reply);
        $sql->bindParam(':reply_ip', $reply_ip);
        // Attempt to execute
        $sql->execute();
		$_SESSION["reply_post"] = "<script>toastr.success('" . lang('reply__post') . "')</script>";
        // Redirect to Item Page
        echo "<script type='text/javascript'>window.location.href = 'item.php?feedback=$item_id';</script>";
		exit(0);

        // Close connection
        $pdo = NULL;

    }

}

function secure_reply($data) {
    trim($data);
    stripslashes($data);
    htmlspecialchars($data);
    return $data;
}

?>