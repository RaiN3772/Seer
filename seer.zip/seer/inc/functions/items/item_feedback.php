<?php

// Include Database Configuration File
require_once "inc/config.php";

// Define variables and initialize with empty values
$feedback = NULL;
$feedbackError = $generalError = NULL;

// Check whether the form is submitted
if (($_SERVER["REQUEST_METHOD"] == "POST") && isset($_POST["feedback_post"])) {

    if (empty($_POST["feedback_post"])) {
        $feedbackError = "You cannot post an empty feedback";
    }
    elseif (strlen($_POST["feedback_post"]) < $feedback_min_length) {
        $feedbackError = "Your Post must have atleast " . $feedback_min_length . " charecters";
    }
	else {
		$feedbackError = NULL;
		$feedback = secure_input($_POST["feedback_post"]);
	}

    $feedback_ip = $_SERVER['REMOTE_ADDR'];

    // Check input error before inserting into database
    if (is_null($feedbackError)) {

        // Prepare insert statement
        $sql = $pdo->prepare("INSERT INTO feedbacks (uid, item_id, feedback_post, feedback_ip) VALUES (:uid, :item_id, :feedback_post, :feedback_ip)");

        // Bind parameters
        $sql->bindParam(':uid', $uid);
        $sql->bindParam(':item_id', $item_id);
        $sql->bindParam(':feedback_post', $feedback);
        $sql->bindParam(':feedback_ip', $feedback_ip);
        // Attempt to execute
        $sql->execute();
		$_SESSION["feedback_post"] = "<script>toastr.success('" . lang('feedback__post') . "')</script>";
        // Redirect to Item Page
        echo "<script type='text/javascript'>window.location.href = 'item.php?feedback=$item_id';</script>";
		exit(0);

        // Close connection
        $pdo = NULL;

    }

}

function secure_input($data) {
    trim($data); // Lets remove whitespace and other predefined characters from both sides of a string
    stripslashes($data); // Lets remove backslashes
    htmlspecialchars($data); // Lets convert some predefined characters to HTML entities; No html tags or scripts and sql injection
    return $data;
}

?>