<?php

$sql = $pdo->prepare("SELECT * FROM feedbacks INNER JOIN users ON feedbacks.uid = users.uid WHERE item_id = :item_id ORDER BY feedback_date DESC");
$sql->bindParam(':item_id', $item_id);
$sql->execute();

$feedbacks_counter = $sql->rowCount();

if ($sql->rowCount() > 0) {
	$feedbacks = $sql->fetchAll(PDO::FETCH_ASSOC);
}
else {
	$feedbacks = NULL;
}



function item_getFeedbacks() {
	
    global $feedbacks;
    foreach ((array) $feedbacks as $feedbacks) {
		$feedback_id = $feedbacks['feedback_id'];
        echo "<div class='card mb-5 mb-xl-8'>";
		echo "<div class='card-body pb-0'>";
		echo "<div class='d-flex align-items-center mb-5'>";
		echo "<div class='d-flex align-items-center flex-grow-1'>";
        echo "<div class='symbol symbol-45px me-5'><img src='". $feedbacks['user_avatar'] . "'></div>";
		echo "<div class='d-flex flex-column'>";
		echo "<a href='profile.php?id=" . $feedbacks['uid'] . "' class='text-gray-900 text-hover-primary fs-6 fw-bolder'>" . $feedbacks['username'] . "</a>";
		echo "<div><span class='text-gray-400 fw-bold me-5'>" . $feedbacks['feedback_date'] . "</span><span class='badge badge-success'>" . $feedbacks['user_title'] . "</span></div>";
        echo "</div>";
		echo "</div>";
		if ((isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) && ($_SESSION['uid'] == $feedbacks['uid'] || $_SESSION['user_type'] == "admin")) { 
		echo "<div class='my-0'>";
        echo "<div class='dropdown'>";
		echo "<button class='btn btn-sm btn-icon btn-color-success btn-active-light-success' type='button' data-bs-toggle='dropdown'>";
		echo "<span class='svg-icon svg-icon-2'>";
		echo svg('item_edit') . "</span>";
		echo "</button>";
		echo "<ul class='dropdown-menu menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-800 menu-state-bg menu-state-primary fw-bold py-4 fs-6 w-275px'>";
		echo "<div class='menu-item px-3'><a href='#' class='menu-link px-3'>Edit</a></div>";
		echo "<div class='menu-item px-3'><a href='#' class='menu-link px-3'>Delete</a></div>";
		echo "</ul>";
        echo "</div>";
		echo "</div>";
		}
		echo "</div>";
		echo "<div class='mb-7'>";
		echo "<p class='text-gray-800 fw-normal mb-5'>" . $feedbacks['feedback_post'] . "</p>";
		echo "</div>";
		item_getfeedbackReplies($feedback_id);
		if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) { item_feedbackPostReply($feedback_id); }
		echo "</div>";
		echo "</div>";
    }
	
	if (is_null($feedbacks)) {
		echo "<div class='alert bg-light-success border border-success border-3 d-flex flex-column flex-sm-row w-100 p-5 mb-10'>";
		echo "<span class='svg-icon svg-icon-2hx svg-icon-success me-4 mb-5 mb-sm-0'>" . svg('item_edit') . "</span>";
		echo "<div class='d-flex flex-column pe-0 pe-sm-10'><h5 class='mb-1'>" . lang('no_feedbacks') . "</h5><span>" . lang('no_feedbacks2') . "</span></div>";
		echo "</div>";
	}
	
	
	
	
    $pdo = null; //Close PDO Connection
    
}

function item_getfeedbackReplies($feedback_id) {
	global $pdo;
	$sql = $pdo->prepare("SELECT * FROM replies INNER JOIN users ON replies.uid = users.uid WHERE feedback_id = :feedback_id ORDER BY reply_date DESC");
	$sql->bindParam(':feedback_id', $feedback_id);
	$sql->execute();
	
	if ($sql->rowCount() > 0) {
		$replies = $sql->fetchAll(PDO::FETCH_ASSOC);
		echo "<div class='separator mb-4'></div>";
	}
	else {
		$replies = NULL;
	}
	foreach ((array) $replies as $replies) {
		echo "<div class='mb-7 ps-10'>";
		echo "<div class='d-flex mb-5'>";
		echo "<div class='symbol symbol-45px me-5'><img src='" . $replies['user_avatar'] . "'></div>";
		echo "<div class='d-flex flex-column flex-row-fluid'>";
		echo "<div class='d-flex align-items-center flex-wrap mb-1'>";
		echo "<a href='profile.php?id=" . $replies['uid'] . "' class='text-gray-800 text-hover-primary fw-bolder me-2'>" . $replies['username'] . "</a>";
		echo "<span class='text-gray-400 fw-bold fs-7'>" . $replies['reply_date'] . "</span>";
		echo "</div>";
		echo "<span class='text-gray-800 fs-7 fw-normal pt-1'>" . $replies['reply_post'] . "</span>";
		echo "</div>";
		echo "</div>";
		echo "</div>";
		
	}
}
function item_feedbackPostReply($feedback_id) {
	
	echo "<div class='separator mb-4'></div>";
	echo "<form class='position-relative mb-6' method='post' action=''>";
	echo "<input type='text' class='form-control border-0 mb-5 p-0' name='reply' placeholder='Reply..' />";
	echo "<input type='hidden' name='feedback_reply_id' value='$feedback_id' />" ;
	echo "<input type='submit' style='display: none' tabindex='-1' />";
	echo "</form>";
}
?>
