<?php
// Include Database Configuration File
require_once "inc/config.php";

// Select Statement
$sql = "SELECT * FROM categories";
$statement = $pdo->query($sql);

// Get all Categories as associative array
$categories = $statement->fetchAll(PDO::FETCH_ASSOC);

function items_getCategories() {
    global $categories;

    foreach ($categories as $categories) {
        echo "<div class='menu-item'>";
        echo "<a class='menu-link' href='items.php?cat_id=" . $categories["category_id"] . "'>";
        echo "<span class='menu-icon'>";
        echo "<span class='svg-icon svg-icon-2'>";
        echo svg('category_icon');
        echo "</span>";
        echo "</span>";
        echo "<span class='menu-title'>" . $categories["category_name"] . "</span>";
        echo "</a>";
        echo "</div>";
    }
    $pdo = null; //Close PDO Connection
    
}

?>
