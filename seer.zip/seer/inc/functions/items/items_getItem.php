<?php
// Include Database Configuration File
require_once "inc/config.php";

if (isset($_GET['id'])) {

    $id = $_GET['id'];

    $sql = $pdo->prepare("SELECT * FROM items INNER JOIN users ON items.uid = users.uid inner Join categories ON items.category_id = categories.category_id WHERE item_id = :id LIMIT 1");
    $sql->bindParam(':id', $id);
    $sql->execute();

    if ($sql->rowCount() > 0) {

        $items = $sql->fetchAll(PDO::FETCH_ASSOC);
        // Bind Values to variables
        foreach ($items as $items) {
            $item_id = $items["item_id"];
            $item_name = $items["item_name"];
            $item_uid = $items["uid"];
            $item_category = $items["category_name"];
            $item_username = $items["username"];
            $item_useravatar = $items["user_avatar"];
            $item_useremail = $items["email"];
            $item_short_description = $items["item_short_description"];
            $item_description = $items["item_description"];
            $item_features = $items["item_features"];
            $item_requirements = $items["item_requirements"];
            $item_thumbnail = $items["item_thumbnail"];
            $item_file = $items["item_file"];
            $item_price = $items["item_price"];
            $item_status = $items["item_status"];
            $item_ip = $items["item_ip"];
            $item_upload_time = $items["item_upload_time"];
            $item_edit_time = $items["item_edit_time"];

        }

    }
	else {
		$_SESSION["invalid_item"] = "<script>toastr.error('" . lang('invalid__item') . "')</script>";
        header("location: items.php");
        exit(0);
    }

}
elseif (isset($_GET['edit'])) {

    $edit = $_GET['edit'];

    $sql = $pdo->prepare("SELECT * FROM items INNER JOIN users ON items.uid = users.uid inner Join categories ON items.category_id = categories.category_id WHERE item_id = :edit LIMIT 1");
    $sql->bindParam(':edit', $edit);
    $sql->execute();

    if ($sql->rowCount() > 0) {

        $items = $sql->fetchAll(PDO::FETCH_ASSOC);
        // Bind Values to variables
        foreach ($items as $items) {
            $item_id = $items["item_id"];
            $item_name = $items["item_name"];
            $item_uid = $items["uid"];
            $item_category = $items["category_name"];
            $item_username = $items["username"];
			$item_useravatar = $items["user_avatar"];
            $item_useremail = $items["email"];
            $item_short_description = $items["item_short_description"];
            $item_description = $items["item_description"];
            $item_features = $items["item_features"];
            $item_requirements = $items["item_requirements"];
            $item_thumbnail = $items["item_thumbnail"];
            $item_file = $items["item_file"];
            $item_price = $items["item_price"];
            $item_status = $items["item_status"];
            $item_ip = $items["item_ip"];
            $item_upload_time = $items["item_upload_time"];
            $item_edit_time = $items["item_edit_time"];

        }

    }
    else {
		$_SESSION["invalid_item"] = "<script>toastr.error('" . lang('invalid__item') . "')</script>";
        header("location: items.php");
        exit(0);
    }

}
elseif (isset($_GET['feedback'])) {

    $feedback_id = $_GET['feedback'];

    $sql = $pdo->prepare("SELECT * FROM items INNER JOIN users ON items.uid = users.uid inner Join categories ON items.category_id = categories.category_id WHERE item_id = :edit LIMIT 1");
    $sql->bindParam(':edit', $feedback_id);
    $sql->execute();

    if ($sql->rowCount() > 0) {

        $items = $sql->fetchAll(PDO::FETCH_ASSOC);
        // Bind Values to variables
        foreach ($items as $items) {
            $item_id = $items["item_id"];
            $item_name = $items["item_name"];
            $item_uid = $items["uid"];
            $item_category = $items["category_name"];
            $item_username = $items["username"];
			$item_useravatar = $items["user_avatar"];
            $item_useremail = $items["email"];
            $item_short_description = $items["item_short_description"];
            $item_description = $items["item_description"];
            $item_features = $items["item_features"];
            $item_requirements = $items["item_requirements"];
            $item_thumbnail = $items["item_thumbnail"];
            $item_file = $items["item_file"];
            $item_price = $items["item_price"];
            $item_status = $items["item_status"];
            $item_ip = $items["item_ip"];
            $item_upload_time = $items["item_upload_time"];
            $item_edit_time = $items["item_edit_time"];

        }

    }

}
else {
	$_SESSION["invalid_item"] = "<script>toastr.error('" . lang('invalid__item') . "')</script>";
    header("location: items.php");
    exit(0);
}

?>
