<?php
// Include Database Configuration File
require_once "inc/config.php";

if ($_GET) { // Specific Category
    $cat_id = $_GET['cat_id'];
	
    // Select Statement
    $sql = $pdo->prepare("SELECT * FROM items INNER JOIN users ON items.uid = users.uid WHERE category_id = :cat_id AND item_status = 'Approved'");
    $sql->bindParam(':cat_id', $cat_id);
    $sql->execute();
	
	if ($sql->rowCount() > 0) {
		// Get all items as associative array
		$items = $sql->fetchAll(PDO::FETCH_ASSOC);
	}
	else {
		$_SESSION["invalid_category"] = "<script>toastr.error('" . lang('invalid__category') . "')</script>";
		header("location: items.php");
        exit(0);
	}
    

}
else { // All Categories

    // Select Statement
    $sql = "SELECT * FROM items inner Join users ON items.uid = users.uid WHERE item_status = 'Approved'";
    $statement = $pdo->query($sql);

    // Get all items as associative array
    $items = $statement->fetchAll(PDO::FETCH_ASSOC);
}

function items_getItems() {
	
    global $items;

    foreach ($items as $items){

        echo "<div class='card mb-3 p-0'>";
        echo "<div class='row g-0'>";
        echo "<div class='col-md-4'>";
        echo "<img src='" . $items["item_thumbnail"] . "' class='img-fluid rounded-start'>";
        echo "</div>";
        echo "<div class='col-md-5'>";
        echo "<div class='card-body'>";
        echo "<a href='item.php?id=" . $items["item_id"] . "' class='card-title fs-2 text-dark text-hover-success'>" . $items["item_name"] . "</a>";
        echo "<a href='profile.php?id=" . $items["uid"] . "' class='card-text d-block mb-2'><small class='text-muted'>By " . $items["username"] . "</small></a>";
        echo "<p class='card-text'>" . $items["item_short_description"] . "</p>";
        if ($items["item_edit_time"] != NULL) { echo "<p class='card-text mt-20'><small class='text-muted'>Last updated " . $items["item_edit_time"] . "</small></p>"; }
        else { echo "<p class='card-text mt-20'><small class='text-muted'>Released on " . $items["item_upload_time"] . "</small></p>"; }
        echo "</div>";
        echo "</div>";
        echo "<div class='col-md-3 border-start'>";
        echo "<div class='card-body d-flex align-items-center flex-column justify-content-center'>";
        echo "<span class='d-block badge badge-dark mt-10'>$" . $items["item_price"] . "</span>";
        echo "<a href='#' class='btn btn-sm btn-dark mt-10'><i class='fas fa-shopping-cart fs-4 me-2'></i>Purchase</a>";
        echo "</div>";
        echo "</div>";
        echo "</div>";
        echo "</div>";

    }
    $pdo = null; // Close PDO Connection
}

?>
