<?php
// Include Database Configuration File
require_once "inc/config.php";

// Select Statement
$sql = "SELECT * FROM categories";
$statement = $pdo->query($sql);

// Get all Categories as associative array
$categories = $statement->fetchAll(PDO::FETCH_ASSOC);

function upload_getCategories() {
	
    global $categories;

    foreach ($categories as $categories) {

        echo "<label class='btn btn-outline btn-outline-dashed btn-outline-default d-flex text-start p-6 mb-6'>";
        echo "<input class='btn-check' type='radio' name='item_category' value='" . $categories["category_id"] . "'>";
        echo "<span class='d-flex'>";
        echo "<span class='svg-icon svg-icon-3hx'>";
        echo svg('category_icon');
        echo "</span>";
        echo "<span class='ms-4'>";
        echo "<span class='fs-3 fw-bolder text-gray-900 mb-2 d-block'>" . $categories["category_name"] . "</span>";
        echo "<span class='fw-bold fs-4 text-muted'>" . $categories["category_description"] . "</span>";
        echo "</span>";
        echo "</span>";
        echo "</label>";
    }
	
    $pdo = null; // Close PDO Connection
   
}

?>
