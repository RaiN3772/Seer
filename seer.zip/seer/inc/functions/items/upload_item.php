<?php

// Include Database Configuration File
require_once "inc/config.php";

// Define variables and initialize with empty values
$itemName = $itemPrice = $itemShortDescription = $itemDescription = $itemThumbnail = $itemFeatures = $itemRequirements = $itemCategory = $itemFile = NULL;
$itemNameError = $itemPriceError = $itemShortDescriptionError = $itemDescriptionError = $itemThumbnailError = $itemCategoryError = $itemFileError = $generalError = NULL;

// Check whether the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (empty($_POST["item_name"])) {
        $itemNameError = "Item Name is required";
    }
    else {
        $itemName = secure_input($_POST["item_name"]);
    }

    if (empty($_POST["item_short_description"])) {
        $itemShortDescriptionError = "Short Description is required";
    }
    else {
        $itemShortDescription = secure_input($_POST["item_short_description"]);
    }

    if (empty($_POST["item_description"])) {
        $itemDescriptionError = "Item Description is required";
    }
    else {
        $itemDescription = secure_input($_POST["item_description"]);
    }

    if (empty($_POST["item_price"])) {
        $itemPriceError = "Item Price is required";
    }
    else {
        $itemPrice = secure_input($_POST["item_price"]);
    }

    if ($_FILES['item_thumbnail']['error'] > 0) {
        $itemThumbnailError = "Item Thumbnail is required";
    }
    else {
        // Item Thumbnail Validation
        include "inc/functions/items/upload_itemThumbnail.php";
    }

    if ($_FILES['item_file']['error'] > 0) {
        $itemFileError = "Item Main File is required";
    }
    else {
        // Item File Validation
        include "inc/functions/items/upload_itemFile.php";
    }

    if (empty($_POST["item_category"])) {
        $itemCategoryError = "Please Select a Category";
    }
    else {
        $itemCategory = secure_input($_POST["item_category"]);
    }

    $itemFeatures = secure_input($_POST["item_features"]);
    $itemRequirements = secure_input($_POST["item_requirements"]);

    $uploaded_item_ip = $_SERVER['REMOTE_ADDR'];
    $uapproved = "Unapproved";
	
	if (isset($itemNameError) || isset($itemPriceError) || isset($itemThumbnailError) || isset($itemDescriptionError) || isset($itemShortDescriptionError) || isset($itemCategoryError) || isset($itemFileError)) {
		$_SESSION["required_item"] = "<script>toastr.error('" . lang('required__item') . "')</script>";
	}

    // Check input error before inserting into database
    if (is_null($itemNameError) && is_null($itemPriceError) && is_null($itemThumbnailError) && is_null($itemDescriptionError) && is_null($itemShortDescriptionError) && is_null($itemCategoryError) && is_null($itemFileError)) {

        // Upload Item Thumbnail to the server
        move_uploaded_file($_FILES["item_thumbnail"]["tmp_name"], $itemThumbnail);
        // Upload Item File to the server
        move_uploaded_file($_FILES["item_file"]["tmp_name"], $itemFile);

        // Prepare insert statement
        $sql = $pdo->prepare("INSERT INTO items (uid, category_id, item_name, item_short_description, item_description, item_features, item_requirements, item_thumbnail, item_file, item_price, item_status, item_ip) VALUES (:uid, :category_id, :item_name, :item_shortdescription, :item_description, :item_features, :item_requirements, :item_thumbnail, :item_file, :item_price, :item_status, :item_ip)");
		
		// Bind parameters variable to prepares statement
		$sql->bindParam(':uid', $uid);
		$sql->bindParam(':category_id', $itemCategory);
		$sql->bindParam(':item_name', $itemName);
		$sql->bindParam(':item_shortdescription', $itemShortDescription);
		$sql->bindParam(':item_description', $itemDescription);
		$sql->bindParam(':item_features', $itemFeatures);
		$sql->bindParam(':item_requirements', $itemRequirements);
		$sql->bindParam(':item_thumbnail', $itemThumbnail);
		$sql->bindParam(':item_file', $itemFile);
		$sql->bindParam(':item_price', $itemPrice);
		$sql->bindParam(':item_status', $uapproved);
		$sql->bindParam(':item_ip', $uploaded_item_ip);
		// Attempt to execute
		$sql->execute();
		$_SESSION["add_item"] = "<script>toastr.success('" . lang('add__item') . " $itemName')</script>";
		// Readirect to items Page
		header('location: items.php');
		exit(0);

        // Close PDO Connection
        $pdo = NULL;

    }
}

function secure_input($data) {
    trim($data); // Lets remove whitespace and other predefined characters from both sides of a string
    stripslashes($data); // Lets remove backslashes
    htmlspecialchars($data); // Lets convert some predefined characters to HTML entities; No html tags or scripts and sql injection
    return $data;
}

