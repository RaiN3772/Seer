<?php
$itemFile_dir = "uploads/Files/"; // Upload Directory
$itemFile = $itemFile_dir . basename($_FILES["item_file"]["name"]); // Path to the file
$itemFileType = strtolower(pathinfo($itemFile, PATHINFO_EXTENSION)); // Get File info


// Check if file already exists (This Function will be changed)
if (file_exists($itemFile)) {
    $itemFileError = "Sorry, file already exists.";
}

// Check file size if greater than 50MB
if ($_FILES["item_thumbnail"]["size"] > 50000000) {
    $itemFileError = "Sorry, your File is too large.";
}

// Check file type, Allow certain file formats
if ($itemFileType != "zip") {
    $itemFileError = "Sorry, only ZIP files are allowed.";
}

?>
