<?php
$itemtThumbnail_dir = "uploads/thumbnails/"; // Upload Directory
$itemThumbnail = $itemtThumbnail_dir . basename($_FILES["item_thumbnail"]["name"]); // Path to the file
$imageFileType = strtolower(pathinfo($itemThumbnail, PATHINFO_EXTENSION)); // Get File info

// Check if the thumbnail file is a actual image or fake image
$check_thumbnail = getimagesize($_FILES["item_thumbnail"]["tmp_name"]);

if ($check_thumbnail != true) {
    $itemThumbnailError = "The Uploaded File is not an image.";
}

// Check if file already exists (This Function will be changed)
if (file_exists($itemThumbnail)) {
    $itemThumbnailError = "Sorry, file already exists.";
}

// Check file size if greater than 5MB
if ($_FILES["item_thumbnail"]["size"] > 5000000) {
    $itemThumbnailError = "Sorry, your thumbnail is too large.";
}

// Check file type, Allow certain file formats
if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
    $itemThumbnailError = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
}

?>
