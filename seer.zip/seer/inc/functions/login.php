<?php
// Initialize the session
session_start();

// Check if the user is already logged in, if yes then redirect to home page
if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) {
    header("location: index.php");
    exit;
}

// Include Database Configuration File
require_once "inc/config.php";

// Define variables and initialize with empty values
$username = $password = $uid = NULL;
$usernameError = $passwordError = $generalError = NULL;

$last_ip = $_SERVER['REMOTE_ADDR']; # Get client IP Address

// Check if the guest is submitted form data
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (empty($_POST["username"])) { // Check if username is empty
        $usernameError = "Username is required";
    }
    else {
        $username = secure_input($_POST["username"]);
    }

    if (empty($_POST["password"])) { // Check if Password is empty
        $passwordError = "Please Enter a Password";
    }
    else {
        $password = secure_input($_POST["password"]);
    }

    // Check input error before logging in
    if (is_null($usernameError) && is_null($passwordError)) {

        // Prepare select statement
        $sql = $pdo->prepare("SELECT * FROM users WHERE username = :username");
        // Bind parameters variable to prepares statement
        $sql->bindParam(':username', $username);

        // Attempt to execute
        $sql->execute();

        if ($sql->rowCount() > 0) {

            // Bind result into variables
            $user = $sql->fetch(PDO::FETCH_ASSOC);

            // Account exists cool, Please verify the password.
            if (password_verify($password, $user['password'])) {
                // Verification success! User has logged-in!
				
                // Update Last Login and Last known IP when loggin in
                $sql = $pdo->prepare("UPDATE users SET last_ip = :last_ip, last_login = now() WHERE uid = :uid");
                $sql->bindParam(':last_ip', $last_ip);
                $sql->bindParam(':uid', $user['uid']);
                $sql->execute();

                // Create a session, so we know if the user is logged in
                // Store data in sessions
                $_SESSION['loggedin'] = true;
                $_SESSION['uid'] = $user['uid'];
                $_SESSION['username'] = $username;
                $_SESSION['user_type'] = $user['user_type'];
                $_SESSION['user_title'] = $user['user_title'];
                $_SESSION['user_avatar'] = $user['user_avatar'];

                // Redirect the user to home page
                header('location: index.php');
				exit(0);

                
            } else {
                $passwordError = 'Incorrect password!';
            }
        } else {
            $usernameError = "Incorrect username!";
        }

        // Close PDO Connection
        $pdo = NULL;
    }
    else {
        $_SESSION["general_error"] = "<script>toastr.error('" . lang('general_error') . " [login]')</script>";
    }
}

function secure_input($data) {
    trim($data); // Lets remove whitespace and other predefined characters from both sides of a string
    stripslashes($data); // Lets remove backslashes
    htmlspecialchars($data); // Lets convert some predefined characters to HTML entities; No html tags or scripts and sql injection
    return $data;
}

