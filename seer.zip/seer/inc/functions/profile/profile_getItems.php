<?php
// Include Database Configuration File
require_once "inc/config.php";

// Select Statement
$sql = $pdo->prepare("SELECT * FROM items inner Join users ON items.uid = users.uid WHERE users.uid = :uid AND item_status = 'Approved'");
$sql->bindParam(':uid', $id);
$sql->execute();

$items_counter = $sql->rowCount();

// Get all items as associative array
$items = $sql->fetchAll(PDO::FETCH_ASSOC);

function profile_getItems()
{

    global $items;
	global $profile_name;
	
	echo "<div class='card mb-5 mb-xl-10'>";
	echo "<div class='card-header'>";
	echo "<div class='card-title m-0'>";
	echo "<h3 class='fw-bolder m-0'>" . $profile_name . "'s Items</h3>";
	echo "</div>";
	echo "</div>";
	echo "<div class='card-body p-9'>";

    foreach ($items as $items)
    {
		echo "<div class='d-flex align-items-sm-center mb-7'>";
        echo "<div class='symbol symbol-60px symbol-2by3 me-4'>";
        echo "<div class='symbol-label' style='background-image: url(" . $items["item_thumbnail"] . ")'></div>";
        echo "</div>";
        echo "<div class='d-flex flex-row-fluid flex-wrap align-items-center'>";
        echo "<div class='flex-grow-1 me-2'>";
        echo "<a href='item.php?id=" . $items["item_id"] . "' class='text-gray-800 fw-bolder text-hover-primary fs-6'>" . $items["item_name"] . "</a>";
        echo "<span class='text-muted fw-bold d-block pt-1'>" . $items["username"] . "</span>";
        echo "</div>";
        echo "<span class='badge badge-light-danger fs-8 fw-bolder my-2'>$" . $items["item_price"] . "</span>";
        echo "</div>";
        echo "</div>";
    }
	echo "</div>";
	echo "</div>";
    
}

?>
