<?php
// Include Database Configuration File
require_once "inc/config.php";

// Select Statement
$sql = $pdo->prepare("SELECT * FROM feedbacks WHERE uid = :uid");
$sql->bindParam(':uid', $id);
$sql->execute();

$feedback_counter = $sql->rowCount();


?>
