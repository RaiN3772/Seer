<?php
// Include Database Configuration File
require_once "inc/config.php";

$sql = $pdo->prepare("SELECT * FROM users WHERE uid = :id LIMIT 1");
$sql->bindParam(':id', $uid);
$sql->execute();

if ($sql->rowCount() > 0)
{

    $profile = $sql->fetchAll(PDO::FETCH_ASSOC);
    // Bind Values to variables
    foreach ($profile as $profile)
    {
        $profile_id = $profile["uid"];
        $profile_name = $profile["username"];
        $profile_email = $profile["email"];
        $profile_type = $profile["user_type"];
        $profile_avatar = $profile["user_avatar"];
        $profile_title = $profile["user_title"];
        $profile_register = $profile["created_at"];
        $profile_registerip = $profile["registered_ip"];
        $profile_lastip = $profile["last_ip"];
        $profile_lastlogin = $profile["last_login"];
        $profile_fullname = $profile["full_name"];
        $profile_website = $profile["website"];
        $profile_gender = $profile["gender"];
        $profile_country = $profile["country"];
        $profile_bio = $profile["bio"];
    }

}
else
{
    $_SESSION["invalid_profile"] = "<script>toastr.error('" . lang('invalid__profile') . "')</script>";
    header("location: index.php");
    exit(0);
}

?>
