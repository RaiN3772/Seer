<?php

// Include Database Configuration File
require_once "inc/config.php";

$newEmail = $confirmEmailPassword = NULL;
$newEmailError = $confirmEmailPasswordError = $generalError = NULL;

if (($_SERVER["REQUEST_METHOD"] == "POST") && isset($_POST["emailaddress"])) {

    if (empty($_POST["emailaddress"])) { 
        $newEmailError = "New Email Address is required";
		$_SESSION["change_email"] = "<script>toastr.error('" . $newEmailError . "')</script>";
    }
    else {
		$newEmail = secure_input($_POST["emailaddress"]);
		if (filter_var($newEmail, FILTER_VALIDATE_EMAIL)) {
			
			$sql = $pdo->prepare("SELECT * FROM users WHERE email = :email");
            $sql->bindParam(':email', $newEmail);
            $sql->execute();

            if ($sql->rowCount() > 0) {
                $newEmailError = "This Email is already taken.";
				$_SESSION["change_email"] = "<script>toastr.error('" . $newEmailError . "')</script>";
                $newEmail = NULL;
            }
			
        }
        else {
            $newEmail = secure_input($_POST["emailaddress"]);
        }
    }

    if (empty($_POST["confirmemailpassword"])) {
        $confirmEmailPasswordError = "Please Confirm your Password";
		$_SESSION["change_email"] = "<script>toastr.error('" . $confirmEmailPasswordError . "')</script>";
    }
    else {
        $confirmEmailPassword = secure_input($_POST["confirmemailpassword"]);
    }

    if (is_null($newEmailError) && is_null($confirmEmailPasswordError)) {

        $sql = $pdo->prepare("SELECT * FROM users WHERE uid = :uid");
        $sql->bindParam(':uid', $uid);

        $sql->execute();
		
		$user = $sql->fetch(PDO::FETCH_ASSOC);
		
		 if (password_verify($confirmEmailPassword, $user['password'])) {
			 $sql = $pdo->prepare("UPDATE users SET email = :email WHERE uid = :uid");
			 $sql->bindParam(':email', $newEmail);
			 $sql->bindParam(':uid', $uid);
			 $sql->execute();
			 $_SESSION["change_email"] = "<script>toastr.success('" . lang('change__email') . "')</script>";
			 header("location: profile.php?id=$uid;");
			 exit(0);
		 }
		 else {
			 $confirmEmailPasswordError = "Incorrect Password";
			 $_SESSION["change_email"] = "<script>toastr.error('" . $confirmEmailPasswordError . "')</script>";
		 }

    }
}

