<?php

// Include Database Configuration File
require_once "inc/config.php";

$currentPassword = $newPassword = $confirmNewPassword = NULL;
$currentPasswordError = $newPasswordError = $confirmNewPasswordError = $generalError = NULL;

if (($_SERVER["REQUEST_METHOD"] == "POST") && isset($_POST["currentpassword"])) {

    if (empty($_POST["currentpassword"])) { 
        $currentPasswordError = "Current Password is required";
		$_SESSION["change_password"] = "<script>toastr.error('" . $currentPasswordError . "')</script>";
    }
    else {
		$currentPassword = secure_input($_POST["currentpassword"]);
    }

    if (empty($_POST["newpassword"])) {
        $newPasswordError = "Please Entera a new Password";
		$_SESSION["change_password"] = "<script>toastr.error('" . $newPasswordError . "')</script>";
    }
	elseif (strlen($_POST["newpassword"]) < $password_min_length) {
        $newPasswordError = "Password must have atleast " . $password_min_length . " charecters";
		$_SESSION["change_password"] = "<script>toastr.error('" . $newPasswordError . "')</script>";
    }
    else {
        $newPassword = secure_input($_POST["newpassword"]);
    }
	
	if (empty($_POST['confirmpassword'])) {
        $confirmPasswordError = "Please confirm the Password";
		$_SESSION["change_password"] = "<script>toastr.error('" . $confirmPasswordError . "')</script>";
    }
    else {
        $confirmNewPassword = secure_input($_POST['confirmpassword']);
        if (is_null($newPasswordError) && ($newPassword != $confirmNewPassword)) {
            $confirmNewPasswordError = "Password did not match";
			$_SESSION["change_password"] = "<script>toastr.error('" . $confirmNewPasswordError . "')</script>";
        }
    }

    if (is_null($currentPasswordError) && is_null($newPasswordError) && is_null($confirmNewPasswordError)) {
		
		$hashed_password = password_hash($newPassword, PASSWORD_DEFAULT);
		
		$sql = $pdo->prepare("SELECT * FROM users WHERE uid = :uid");
        $sql->bindParam(':uid', $uid);
        $sql->execute();
		
		$user = $sql->fetch(PDO::FETCH_ASSOC);
		
		 if (password_verify($currentPassword, $user['password'])) {
			 $sql = $pdo->prepare("UPDATE users SET password = :password WHERE uid = :uid");
			 $sql->bindParam(':password', $hashed_password);
			 $sql->bindParam(':uid', $uid);
			 $sql->execute();
			 $_SESSION["change_password"] = "<script>toastr.success('" . lang('change__password') . "')</script>";
			 header("location: profile.php?id=$uid;");
			 exit(0);
		 }
		 else {
			 $currentPasswordError = "Incorrect Password";
			 $_SESSION["change_password"] = "<script>toastr.error('" . $currentPasswordError . "')</script>";
		 }

    }
}

