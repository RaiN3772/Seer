<?php
// Include Database Configuration File
require_once "inc/config.php";

// Define variables and initialize with empty values
$full_name = $gender = $website = $country = $bio = NULL;
$generalError = NULL;

$user_title = "Default Title";

// Check whether the form is submitted
if (($_SERVER["REQUEST_METHOD"] == "POST") && (isset($_POST['full_name']) || isset($_POST['gender']) || isset($_POST['website']) || isset($_POST['country']) || isset($_POST['bio']))) {
	
	if (!empty($_POST['full_name'])) {
		$full_name = secure_input($_POST["full_name"]);
	}
	if (!empty($_POST['user_title'])) {
		$user_title = secure_input($_POST["user_title"]);
	}
	if (!empty($_POST['gender'])) {
		$gender = secure_input($_POST["gender"]);
	}
	if (!empty($_POST['website'])) {
		$website = secure_input($_POST["website"]);
	}
	if (!empty($_POST['country'])) {
		$country = secure_input($_POST["country"]);
	}
	if (!empty($_POST['bio'])) {
		$bio = secure_input($_POST["bio"]);
	}


    if (isset($full_name) || isset($gender) || isset($website) || isset($country) || isset($bio)) {
        $sql = $pdo->prepare("UPDATE users set full_name = :full_name, user_title = :user_title, gender = :gender, website = :website, country = :country, bio = :bio WHERE uid = :uid");

        $sql->bindParam(':full_name', $full_name);
        $sql->bindParam(':user_title', $user_title);
        $sql->bindParam(':gender', $gender);
        $sql->bindParam(':website', $website);
        $sql->bindParam(':country', $country);
        $sql->bindParam(':bio', $bio);
		$sql->bindParam(':uid', $uid);
        $sql->execute();
        
        $_SESSION["update_profile"] = "<script>toastr.success('" . lang('update__profile') . "')</script>";
        echo "<script type='text/javascript'>window.location.href = 'settings.php';</script>";
        exit(0);

    }
	else {
		$_SESSION["update_profile"] = "<script>toastr.error('You cannot save empty values')</script>";
        echo "<script type='text/javascript'>window.location.href = 'settings.php';</script>";
        exit(0);
	}

}

function secure_input($data) {
    trim($data);
    stripslashes($data);
    htmlspecialchars($data);
    return $data;
}
?>
