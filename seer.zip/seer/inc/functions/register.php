<?php
// Initialize the session
session_start();

// Check if the user is already logged in, if yes then redirect him to welcome page
if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) {
    header("location: index.php");
    exit;
}

// Include Database Configuration File
require_once "inc/config.php";

// Define variables and initialize with empty values
$username = $password = $confirmPassword = $email = NULL;
$usernameError = $passwordError = $confirmPasswordError = $emailError = $generalError = NULL;

$registered_ip = $_SERVER['REMOTE_ADDR']; # Get client IP Address

// Check whether the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (empty($_POST["username"])) { // Check if username is empty
        $usernameError = "Username is required";
    }
    elseif (strlen($_POST["username"]) < $username_min_length) { // Get username length and check if it have atleast $username_min_length charecters
        $usernameError = "Username must have atleast " . $username_min_length . " charecters";
    }
    else {
        $username = secure_input($_POST["username"]);

        $sql = $pdo->prepare("SELECT * FROM users WHERE username = :username");
        $sql->bindParam(':username', $username);
        $sql->execute();

        if ($sql->rowCount() > 0) { // Check whether if the username is already taken
            $usernameError = "This username is already taken.";
            $username = NULL;
        }

    }

    if (empty($_POST["email"])) { // Check if Email is empty
        $emailError = "Email is required";
    }
    else {
        $email = secure_input($_POST["email"]);
        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {

            $sql = $pdo->prepare("SELECT * FROM users WHERE email = :email");
            $sql->bindParam(':email', $email);
            $sql->execute();

            if ($sql->rowCount() > 0) { // Check whether if the Email is already taken
                $emailError = "This Email is already taken.";
                $email = NULL;
            }
        }
        else {
            $emailError = "Invalid Email Address";
        }
    }

    if (empty($_POST["password"])) { // Check if Password is empty
        $passwordError = "Please Enter a Password";
    }
    elseif (strlen($_POST["password"]) < $password_min_length) { // Get password length and check if it have atleast $password_min_length charecters
        $passwordError = "Password must have atleast " . $password_min_length . " charecters";
    }
    else {
        $password = secure_input($_POST["password"]);
    }

    if (empty($_POST['confirmPassword'])) { // Check if confirmPassword is empty
        $confirmPasswordError = "Please confirm the Password";
    }
    else {
        $confirmPassword = secure_input($_POST['confirmPassword']);
        if (is_null($passwordError) && ($password != $confirmPassword)) { // Check if the confirmed password matches the password
            $confirmPasswordError = "Password did not match";
        }
    }

    // Check input error before inserting into database
    if (is_null($usernameError) && is_null($passwordError) && is_null($confirmPasswordError) && is_null($emailError)) {

        // Prepare insert statement
        $sql = $pdo->prepare("INSERT INTO users (username, email, password, registered_ip) VALUES (:username, :email, :password, :registered_ip)");

        $hashed_password = password_hash($password, PASSWORD_DEFAULT); // Encrypt the password
        // Bind parameters
        $sql->bindParam(':username', $username);
        $sql->bindParam(':email', $email);
        $sql->bindParam(':password', $hashed_password);
        $sql->bindParam(':registered_ip', $registered_ip);
        // Attempt to execute
        $sql->execute();
		$_SESSION["register_user"] = "<script>toastr.success('" . lang('register__user') . " $username')</script>";
        // Redirect to Home page
        header('location: login.php');
		exit(0);

        // Close connection
        $pdo = NULL;

    }
    else {
       $_SESSION["general_error"] = "<script>toastr.error('" . lang('general_error') . " [register]')</script>";
    }

}

function secure_input($data) {
    trim($data); // Lets remove whitespace and other predefined characters from both sides of a string
    stripslashes($data); // Lets remove backslashes
    htmlspecialchars($data); // Lets convert some predefined characters to HTML entities; No html tags or scripts and sql injection
    return $data;
}

