<?php
// Initialize the session
session_start();

$username = NULL;
$uid = NULL;
$usertype = NULL;
$usertitle = NULL;
$useravatar = NULL;

// Check whether the user logged in or not
if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) {
	$username = $_SESSION['username'];
	$uid = $_SESSION['uid'];
	$usertype = $_SESSION['user_type'];
	$usertitle = $_SESSION['user_title'];
	$useravatar = $_SESSION['user_avatar'];
}

?>