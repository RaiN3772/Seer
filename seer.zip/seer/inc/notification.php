<?php
if (isset($_SESSION["add_user"])) {
	echo $_SESSION["add_user"];
	unset ($_SESSION["add_user"]);
}
if (isset($_SESSION["edit_user"])) {
	echo $_SESSION["edit_user"];
	unset ($_SESSION["edit_user"]);
}
if (isset($_SESSION["delete_user"])) {
	echo $_SESSION["delete_user"];
	unset ($_SESSION["delete_user"]);
}
if (isset($_SESSION["register_user"])) {
	echo $_SESSION["register_user"];
	unset ($_SESSION["register_user"]);
}

if (isset($_SESSION["add_item"])) {
	echo $_SESSION["add_item"];
	unset ($_SESSION["add_item"]);
}
if (isset($_SESSION["edit_item"])) {
	echo $_SESSION["edit_item"];
	unset ($_SESSION["edit_item"]);

}
if (isset($_SESSION["delete_item"])) {
	echo $_SESSION["delete_item"];
	unset ($_SESSION["delete_item"]);
}
if (isset($_SESSION["approve_item"])) {
	echo $_SESSION["approve_item"];
	unset ($_SESSION["approve_item"]);
}

if (isset($_SESSION["invalid_item"])) {
	echo $_SESSION["invalid_item"];
	unset ($_SESSION["invalid_item"]);
}

if (isset($_SESSION["required_item"])) {
	echo $_SESSION["required_item"];
	unset ($_SESSION["required_item"]);
}

if (isset($_SESSION["add_category"])) {
	echo $_SESSION["add_category"];
	unset ($_SESSION["add_category"]);
}
if (isset($_SESSION["edit_category"])) {
	echo $_SESSION["edit_category"];
	unset ($_SESSION["edit_category"]);
}
if (isset($_SESSION["delete_category"])) {
	echo $_SESSION["delete_category"];
	unset ($_SESSION["delete_category"]);
}
if (isset($_SESSION["invalid_category"])) {
	echo $_SESSION["invalid_category"];
	unset ($_SESSION["invalid_category"]);
}

if (isset($_SESSION["feedback_post"])) {
	echo $_SESSION["feedback_post"];
	unset ($_SESSION["feedback_post"]);
}

if (isset($_SESSION["reply_post"])) {
	echo $_SESSION["reply_post"];
	unset ($_SESSION["reply_post"]);
}

if (isset($_SESSION["invalid_profile"])) {
	echo $_SESSION["invalid_profile"];
	unset ($_SESSION["invalid_profile"]);
}
if (isset($_SESSION["update_profile"])) {
	echo $_SESSION["update_profile"];
	unset ($_SESSION["update_profile"]);
}
if (isset($_SESSION["change_email"])) {
	echo $_SESSION["change_email"];
	unset ($_SESSION["change_email"]);
}
if (isset($_SESSION["change_password"])) {
	echo $_SESSION["change_password"];
	unset ($_SESSION["change_password"]);
}




if (isset($_SESSION["general_error"])) {
	echo $_SESSION["general_error"];
	unset ($_SESSION["general_error"]);
}
if (isset($_SESSION["permission_denied"])) {
	echo $_SESSION["permission_denied"];
	unset ($_SESSION["permission_denied"]);
}

?>