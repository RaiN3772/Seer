<?php

// General Configuration
$website_name = "Seer";
$website_url = "index.php";
$favicon_url = "assets/images/favicon.ico";
$logo_url = "assets/images/seer.png";
$active_website = 1; // Determine whether if the website is closed or not [Default: 1]
$active_website_msg = "The Website is currently closed for maintenance. Please check back later.";

// Registration Configuration
$username_min_length = 4;
$password_min_length = 8;
$usertitle_max_length = 15;

// Feedback Configuration
$feedback_min_length = 10;
$feedback_max_length = 280;

// Profile Configuration
$display_uid = 1; // Display User ID on User Profile [Default: 1]
$bio_max_length = 500;
$private_profile = 0; // Allow Guests to see profiles [Default: 0]


// This is where you stop. Editing anything below this point, might lead to some serious errors
// Do not edit if you don't know what this is
$project_version = 1.21;
$sleep_time = 2;
$activePage = basename($_SERVER['PHP_SELF'], ".php"); // Header Active Class
if ($active_website == 0 && $usertype != "admin") { header('location: error.php'); exit(0);}

?>
