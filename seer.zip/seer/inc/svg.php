<?php
function svg($icon)
{
    static $svg = array(
        "header_menu_toggle" => "<svg width='24' height='24' viewBox='0 0 24 24' fill='none'>
            <path d='M21 7H3C2.4 7 2 6.6 2 6V4C2 3.4 2.4 3 3 3H21C21.6 3 22 3.4 22 4V6C22 6.6 21.6 7 21 7Z' fill='black' />
            <path opacity='0.3' d='M21 14H3C2.4 14 2 13.6 2 13V11C2 10.4 2.4 10 3 10H21C21.6 10 22 10.4 22 11V13C22 13.6 21.6 14 21 14ZM22 20V18C22 17.4 21.6 17 21 17H3C2.4 17 2 17.4 2 18V20C2 20.6 2.4 21 3 21H21C21.6 21 22 20.6 22 20Z' fill='black' />
          </svg>",
        "header_menu_search" => "<svg width='24' height='24' viewBox='0 0 24 24' fill='none''>
  <path d='M21.7 18.9L18.6 15.8C17.9 16.9 16.9 17.9 15.8 18.6L18.9 21.7C19.3 22.1 19.9 22.1 20.3 21.7L21.7 20.3C22.1 19.9 22.1 19.3 21.7 18.9Z' fill='black' />
  <path opacity='0.3' d='M11 20C6 20 2 16 2 11C2 6 6 2 11 2C16 2 20 6 20 11C20 16 16 20 11 20ZM11 4C7.1 4 4 7.1 4 11C4 14.9 7.1 18 11 18C14.9 18 18 14.9 18 11C18 7.1 14.9 4 11 4ZM8 11C8 9.3 9.3 8 11 8C11.6 8 12 7.6 12 7C12 6.4 11.6 6 11 6C8.2 6 6 8.2 6 11C6 11.6 6.4 12 7 12C7.6 12 8 11.6 8 11Z' fill='black' />
</svg>",
        "header_menu_user" => "<svg width='24' height='24' viewBox='0 0 24 24' fill='none'>
  <path d='M6.28548 15.0861C7.34369 13.1814 9.35142 12 11.5304 12H12.4696C14.6486 12 16.6563 13.1814 17.7145 15.0861L19.3493 18.0287C20.0899 19.3618 19.1259 21 17.601 21H6.39903C4.87406 21 3.91012 19.3618 4.65071 18.0287L6.28548 15.0861Z' fill='black' />
  <rect opacity='0.3' x='8' y='3' width='8' height='8' rx='4' fill='black' />
</svg>",
        "modal_close" => "<svg width='24' height='24' viewBox='0 0 24 24' fill='none'>
              <rect opacity='0.5' x='6' y='17.3137' width='16' height='2' rx='1' transform='rotate(-45 6 17.3137)' fill='black' />
              <rect x='7.41422' y='6' width='16' height='2' rx='1' transform='rotate(45 7.41422 6)' fill='black' />
            </svg>",
        "category_icon" => "<svg width='24' height='24' viewBox='0 0 24 24' fill='none'>
    <path d='M3 2H10C10.6 2 11 2.4 11 3V10C11 10.6 10.6 11 10 11H3C2.4 11 2 10.6 2 10V3C2 2.4 2.4 2 3 2Z' fill='black'/>
    <path opacity='0.3' d='M14 2H21C21.6 2 22 2.4 22 3V10C22 10.6 21.6 11 21 11H14C13.4 11 13 10.6 13 10V3C13 2.4 13.4 2 14 2Z' fill='black'/>
    <path opacity='0.3' d='M3 13H10C10.6 13 11 13.4 11 14V21C11 21.6 10.6 22 10 22H3C2.4 22 2 21.6 2 21V14C2 13.4 2.4 13 3 13Z' fill='black'/>
    <path opacity='0.3' d='M14 13H21C21.6 13 22 13.4 22 14V21C22 21.6 21.6 22 21 22H14C13.4 22 13 21.6 13 21V14C13 13.4 13.4 13 14 13Z' fill='black'/>
  </svg>",
        "minus" => "<svg width='24' height='24' viewBox='0 0 24 24' fill='none'>
                            <rect opacity='0.3' x='2' y='2' width='20' height='20' rx='10' fill='black' />
                            <rect x='6.01041' y='10.9247' width='12' height='2' rx='1' fill='black' />
                          </svg>",
        "plus" => "<svg width='24' height='24' viewBox='0 0 24 24' fill='none'>
                            <rect opacity='0.3' x='2' y='2' width='20' height='20' rx='10' fill='black' />
                            <rect x='10.8891' y='17.8033' width='12' height='2' rx='1' transform='rotate(-90 10.8891 17.8033)' fill='black' />
                            <rect x='6.01041' y='10.9247' width='12' height='2' rx='1' fill='black' />
                          </svg>",
        "upload_file" => "<svg width='24' height='24' viewBox='0 0 24 24' fill='none'>
                            <path opacity='0.3' d='M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM16 12.6L12.7 9.3C12.3 8.9 11.7 8.9 11.3 9.3L8 12.6H11V18C11 18.6 11.4 19 12 19C12.6 19 13 18.6 13 18V12.6H16Z' fill='black' />
                            <path d='M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z' fill='black' />
                          </svg>",
        "rating_star" => "<svg width='24' height='24' viewBox='0 0 24 24' fill='none'>
  <path d='M11.1359 4.48359C11.5216 3.82132 12.4784 3.82132 12.8641 4.48359L15.011 8.16962C15.1523 8.41222 15.3891 8.58425 15.6635 8.64367L19.8326 9.54646C20.5816 9.70867 20.8773 10.6186 20.3666 11.1901L17.5244 14.371C17.3374 14.5803 17.2469 14.8587 17.2752 15.138L17.7049 19.382C17.7821 20.1445 17.0081 20.7069 16.3067 20.3978L12.4032 18.6777C12.1463 18.5645 11.8537 18.5645 11.5968 18.6777L7.69326 20.3978C6.99192 20.7069 6.21789 20.1445 6.2951 19.382L6.7248 15.138C6.75308 14.8587 6.66264 14.5803 6.47558 14.371L3.63339 11.1901C3.12273 10.6186 3.41838 9.70867 4.16744 9.54646L8.3365 8.64367C8.61089 8.58425 8.84767 8.41222 8.98897 8.16962L11.1359 4.48359Z' fill='black'></path>
</svg>",
        "continue_google" => "assets/media/svg/brand-logos/google-icon.svg",
        "continue_facebook" => "assets/media/svg/brand-logos/facebook-4.svg",
        "default_icon" => "<i class='fab fa-fonticons-fi fs-4'></i>",
        "item_plus" => "<svg width='24' height='24' viewBox='0 0 24 24' fill='none'>
            <rect opacity='0.5' x='11.364' y='20.364' width='16' height='2' rx='1' transform='rotate(-90 11.364 20.364)' fill='black'></rect>
            <rect x='4.36396' y='11.364' width='16' height='2' rx='1' fill='black'></rect>
          </svg>",
        "item_edit" => "<svg width='24' height='24' viewBox='0 0 24 24' fill='none'>
                      <path opacity='0.3' d='M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z' fill='black'></path>
                      <path d='M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z' fill='black'></path>
                    </svg>",
        "item_delete" => "<svg width='24' height='24' viewBox='0 0 24 24' fill='none'>
                      <path d='M5 9C5 8.44772 5.44772 8 6 8H18C18.5523 8 19 8.44772 19 9V18C19 19.6569 17.6569 21 16 21H8C6.34315 21 5 19.6569 5 18V9Z' fill='black'></path>
                      <path opacity='0.5' d='M5 5C5 4.44772 5.44772 4 6 4H18C18.5523 4 19 4.44772 19 5V5C19 5.55228 18.5523 6 18 6H6C5.44772 6 5 5.55228 5 5V5Z' fill='black'></path>
                      <path opacity='0.5' d='M9 4C9 3.44772 9.44772 3 10 3H14C14.5523 3 15 3.44772 15 4V4H9V4Z' fill='black'></path>
                    </svg>",
        "item_approve" => "<i class='fas fa-thumbs-up'></i>",
        "item_unapprove" => "<i class='fas fa-thumbs-down'></i>",
        "scroll_to_top" => "<svg width='24' height='24' viewBox='0 0 24 24' fill='none'>
      <rect opacity='0.5' x='13' y='6' width='13' height='2' rx='1' transform='rotate(90 13 6)' fill='black' />
      <path d='M12.5657 8.56569L16.75 12.75C17.1642 13.1642 17.8358 13.1642 18.25 12.75C18.6642 12.3358 18.6642 11.6642 18.25 11.25L12.7071 5.70711C12.3166 5.31658 11.6834 5.31658 11.2929 5.70711L5.75 11.25C5.33579 11.6642 5.33579 12.3358 5.75 12.75C6.16421 13.1642 6.83579 13.1642 7.25 12.75L11.4343 8.56569C11.7467 8.25327 12.2533 8.25327 12.5657 8.56569Z' fill='black' />
    </svg>",
        "default_icon" => "<i class='fab fa-fonticons-fi fs-4'></i>",
    );
    return (!array_key_exists($icon, $svg)) ? $icon : $svg[$icon];
}
?>
