<div id="kt_aside" class="aside card" data-kt-drawer="true" data-kt-drawer-name="aside" data-kt-drawer-activate="{default: true, lg: false}" data-kt-drawer-overlay="true" data-kt-drawer-width="{default:'200px', '300px': '250px'}" data-kt-drawer-direction="start" data-kt-drawer-toggle="#kt_aside_toggle" data-kt-sticky="true" data-kt-sticky-name="aside-sticky" data-kt-sticky-offset="{default: false, lg: '200px'}" data-kt-sticky-width="{lg: '265px'}" data-kt-sticky-left="auto" data-kt-sticky-top="95px" data-kt-sticky-animation="true" data-kt-sticky-zindex="95">
  <div class="aside-menu flex-column-fluid">
    <div class="hover-scroll-overlay-y my-5 my-lg-6" id="kt_aside_menu_wrapper" data-kt-scroll="true" data-kt-scroll-activate="{default: false, lg: true}" data-kt-scroll-height="auto" data-kt-scroll-dependencies="#kt_header" data-kt-scroll-wrappers="#kt_aside, #kt_aside_menu" data-kt-scroll-offset="{lg: '25px'}">
      <div class="menu menu-column menu-title-gray-800 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-500" id="#kt_aside_menu" data-kt-menu="true">
        <div class="menu-item">
          <div class="menu-content pb-2">
            <a href="admin.php" class="menu-section text-muted fs-8 ls-1"><?=lang('admin_panel');?></a>
          </div>
        </div>
        <div class="menu-item">
          <a class="menu-link" href="?items">
          <span class="menu-icon"><i class="fas fa-sitemap"></i></span>
          <span class="menu-title"><?=lang('items');?></span>
          </a>
        </div>
        <div class="menu-item">
          <a class="menu-link" href="?items=unapproved">
          <span class="menu-icon"><i class="fas fa-thumbs-down"></i></span>
          <span class="menu-title"><?=lang('unapproved');?> <?=lang('items');?></span>
          </a>
        </div>
        <div class="separator my-2"></div>
        <div class="menu-item">
          <a class="menu-link" href="?categories">
          <span class="menu-icon"><i class="fas fa-th-large"></i></span>
          <span class="menu-title"><?=lang('categories');?></span>
          </a>
        </div>
        <div class="menu-item">
          <a class="menu-link" href="?add_cat">
          <span class="menu-icon"><i class="far fa-plus-square"></i></span>
          <span class="menu-title"><?=lang('add_category');?></span>
          </a>
        </div>
        <div class="separator my-2"></div>
        <div class="menu-item">
          <a class="menu-link" href="?users">
          <span class="menu-icon"><i class="fas fa-users"></i></span>
          <span class="menu-title"><?=lang('users');?></span>
          </a>
        </div>
        <div class="menu-item">
          <a class="menu-link" href="?add_user">
          <span class="menu-icon"><i class="fas fa-user-plus"></i></span>
          <span class="menu-title"><?=lang('add_user');?></span>
          </a>
        </div>
        <div class="separator my-2"></div>
		<div class="menu-item">
          <a class="menu-link" href="?logs">
          <span class="menu-icon"><i class="fas fa-history"></i></span>
          <span class="menu-title"><?=lang('logs');?></span>
          </a>
        </div>
		<div class="separator my-2"></div>
		<div class="menu-item">
          <div class="menu-content pb-2">
            <a class="menu-section text-muted fs-8 ls-1">Documentation</a>
          </div>
        </div>
		<div class="menu-item">
          <a class="menu-link" href="documentation.php?references">
          <span class="menu-icon"><i class="fas fa-passport"></i></span>
          <span class="menu-title">References</span>
          </a>
        </div>
		<div class="menu-item">
          <a class="menu-link" href="documentation.php?files">
          <span class="menu-icon"><i class="fas fa-folder-open"></i></span>
          <span class="menu-title">File Structure</span>
          </a>
        </div>
      </div>
    </div>
  </div>
</div>