<?php include 'inc/functions/admin/categories_addCategory.php'; ?>
<div class="card card-xxl-stretch mb-5 mb-xl-8">
  <div class="card-header border-0 pt-5">
    <h3 class="card-title align-items-start flex-column">
      <span class="card-label fw-bolder fs-3 mb-1"><?=lang('add_category');?></span>
    </h3>
  </div>
  <div class="card-body py-3">
    <form class="form" novalidate="novalidate" action="admin.php?add_cat" method="post">
      <div class="input-group mb-5">
        <span class="input-group-text required"><?=lang('category_name');?></span>
        <input type="text" class="form-control" name="category_name" placeholder="Enter a Category Name"/>
        <div class="fv-plugins-message-container invalid-feedback"><?=$categoryNameError;?></div>
      </div>
      <div class="input-group">
        <span class="input-group-text required"><?=lang('category_description');?></span>
        <textarea class="form-control" name="category_description" placeholder="Enter a Category Description" rows="1"></textarea>
        <div class="fv-plugins-message-container invalid-feedback"><?=$categoryDescriptionError;?></div>
      </div>
      <button type="submit" class="btn btn-primary mt-5 mb-5" style="float: right;">Add Category</button>
    </form>
  </div>
</div>