<?php include 'inc/functions/admin/logs_getLogs.php'; ?>
<div class="card mb-5 mb-lg-10">
  <div class="card-header">
    <div class="card-title"><h3><?=lang('logs');?></h3><span class="badge badge-light-success fs-7 fw-bolder ms-5"><?=$log_counter;?> <?=lang('logs');?></span></div>
    <div class="card-toolbar">
      <div class="my-1 me-4">
	  <form action="" method="post">
        <select class="form-select form-select-sm form-select-solid w-125px" id="filter" name="filter">
          <option selected disabled hidden><?=lang('filter');?></option>
          <option value="users" <?=$filter == "users" ? "selected" : "" ?>>Users</option>
          <option value="items" <?=$filter == "items" ? "selected" : "" ?>>Items</option>
          <option value="categories" <?=$filter == "categories" ? "selected" : "" ?>>Categories</option>
        </select>
		</form>
      </div>
      <a href="?logs" class="btn btn-sm btn-primary my-1">View All</a>
    </div>
  </div>

  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="table table-flush align-middle table-row-bordered table-row-solid gy-4 gs-9">
        <thead class="border-gray-200 fs-5 fw-bold bg-lighten">
          <tr>
            <th class="min-w-150px"><?=lang('user');?></th>
            <th class="min-w-200px"><?=lang('action');?></th>
            <th class="min-w-250px"><?=lang('information');?></th>
            <th class="min-w-150px"><?=lang('ipaddress');?></th>
            <th class="min-w-150px"><?=lang('time');?></th>
          </tr>
        </thead>
        <tbody class="fw-6 fw-bold text-gray-600">
		<?php logs_getLogs(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>