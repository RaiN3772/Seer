<?php include 'inc/functions/admin/users_addUser.php'; ?>
<div class="card card-xxl-stretch mb-5 mb-xl-8">
  <div class="card-header border-0 pt-5">
    <h3 class="card-title align-items-start flex-column">
      <span class="card-label fw-bolder fs-3 mb-1"><?=lang('add_user');?></span>
    </h3>
  </div>
  <div class="card-body py-3">
    <form class="form" novalidate="novalidate" action="admin.php?add_user" method="post">
      <div class="mb-10">
        <label class="required form-label"><?=lang('username');?></label>
        <input type="text" name="username" class="form-control form-control-solid" placeholder="Enter a Username"/>
        <div class="fv-plugins-message-container invalid-feedback"><?=$usernameError;?></div>
      </div>
      <div class="mb-10">
        <label class="required form-label"><?=lang('email');?></label>
        <input type="email" name="email" class="form-control form-control-solid" placeholder="Enter an Email"/>
        <div class="fv-plugins-message-container invalid-feedback"><?=$emailError;?></div>
      </div>
      <div class="mb-10">
        <label class="required form-label"><?=lang('password');?></label>
        <input type="password" name="password" class="form-control form-control-solid" placeholder="Enter a Password"/>
        <div class="text-muted"><?=lang('password_charecter');?></div>
        <div class="fv-plugins-message-container invalid-feedback"><?=$passwordError;?></div>
      </div>
      <div class="mb-10">
        <label class="required form-label"><?=lang('confirm_password');?></label>
        <input type="password" name="confirmPassword" class="form-control form-control-solid" placeholder="Confirm the Password"/>
        <div class="fv-plugins-message-container invalid-feedback"><?=$confirmPasswordError;?></div>
      </div>
      <div class="mb-10">
        <label class="required form-label"><?=lang('user_type');?></label>
        <select class="form-select form-select-lg mb-3" name="userType">
          <option selected disabled hidden><?=lang('choose');?></option>
          <option value="user"><?=lang('user');?></option>
          <option value="admin"><?=lang('admin');?></option>
        </select>
        <div class="fv-plugins-message-container invalid-feedback"><?=$userTypeError;?></div>
      </div>
      <button type="submit" class="btn btn-primary mt-5 mb-5" style="float: right;"><?=lang('add_user');?></button>
    </form>
  </div>
</div>