<?php include 'inc/functions/admin/users_editUser.php'; ?>
<div class="card card-xxl-stretch mb-5 mb-xl-8">
  <div class="card-header border-0 pt-5">
    <h3 class="card-title align-items-start flex-column">
      <span class="card-label fw-bolder fs-3 mb-1"><?=lang('edit');?> <?=$user_username;?></span>
    </h3>
  </div>
  <div class="card-body py-3">
    <form class="form" novalidate="novalidate" action="admin.php?edit_user=<?=$user_id;?>" method="post">
      <div class="mb-10">
        <label class="required form-label"><?=lang('username');?></label>
        <input type="text" name="username" class="form-control form-control-solid" placeholder="Enter a Username" value="<?=$user_username;?>" />
        <div class="fv-plugins-message-container invalid-feedback"><?=$usernameError;?></div>
      </div>
      <div class="mb-10">
        <label class="form-label"><?=lang('user_title');?></label>
        <input type="text" name="usertitle" class="form-control form-control-solid" placeholder="Enter a Title" value="<?=$user_title;?>" />
        <div class="fv-plugins-message-container invalid-feedback"><?=$userTitleError;?></div>
      </div>
      <div class="mb-10">
        <label class="required form-label"><?=lang('email');?></label>
        <input type="email" name="email" class="form-control form-control-solid" placeholder="Enter an Email" value="<?=$user_email;?>"/>
        <div class="fv-plugins-message-container invalid-feedback"><?=$emailError;?></div>
      </div>
      <div class="mb-10">
        <label class="form-label"><?=lang('new_password');?></label>
        <input type="password" name="password" class="form-control form-control-solid" placeholder="Enter a New Password"/>
        <div class="text-muted"><?=lang('leave_password');?></div>
        <div class="fv-plugins-message-container invalid-feedback"><?=$passwordError;?></div>
      </div>
      <div class="mb-10">
        <label class="form-label"><?=lang('confirm_new_password');?></label>
        <input type="password" name="confirmPassword" class="form-control form-control-solid" placeholder="Confirm the Password"/>
        <div class="fv-plugins-message-container invalid-feedback"><?=$confirmPasswordError;?></div>
      </div>
      <div class="mb-10">
        <label class="required form-label"><?=lang('user_type');?></label>
        <select class="form-select form-select-lg mb-3" name="userType" aria-label="country">
          <option selected disabled hidden><?=lang('choose');?></option>
          <option value="user" <?=$user_type == "user" ? "selected" : "" ?>><?=lang('user');?></option>
          <option value="admin"<?=$user_type == "admin" ? "selected" : "" ?>><?=lang('admin');?></option>
        </select>
        <div class="fv-plugins-message-container invalid-feedback"><?=$userTypeError;?></div>
      </div>
      <button type="submit" class="btn btn-primary mt-5 mb-5" style="float: right;"><?=lang('edit');?> <?=$user_username;?></button>
    </form>
  </div>
</div>