<div class="footer py-4 d-flex flex-lg-column" id="kt_footer">
  <div class="container-xxl d-flex flex-column flex-md-row align-items-center justify-content-between">
    <div class="text-dark order-2 order-md-1">
      <span class="text-muted fw-bold me-1"><?= date('Y');?> ©</span>
      <a href="<?=$website_url;?>" target="_blank" class="text-gray-800 text-hover-primary"><?=$website_name;?></a>, <?=lang('current_version');?>: <?=$project_version;?>
    </div>
	<form action="" method="post" class="order-1">
    <select class="form-select form-control-solid w-200px" id="mode" name="mode">
	<optgroup label="Quick Mode Select">
      <option selected disabled hidden>Quick Mode Select</option>
      <option value="light" <?=$mode == "light" ? "selected" : "" ?>>Light</option>
      <option value="dark" <?=$mode == "dark" ? "selected" : "" ?>>Dark</option>
	  </optgroup>
    </select>
	</form>
    <!--
      <ul class="menu menu-gray-600 menu-hover-primary fw-bold order-1">
        <li class="menu-item"><a href="#" target="_blank" class="menu-link px-2">Link #1</a></li>
        <li class="menu-item"><a href="#" target="_blank" class="menu-link px-2">Link #2</a></li>
        <li class="menu-item"><a href="#" target="_blank" class="menu-link px-2">Link #3</a></li>
      </ul>
      -->
  </div>
</div>