<?php include 'inc/functions/header/header_getCategories.php';?>
<div id="kt_header" class="header" data-kt-sticky="true" data-kt-sticky-name="header">
  <div class="container-xxl d-flex flex-grow-1 flex-stack">
    <div class="d-flex align-items-center me-5">
      <div class="d-lg-none btn btn-icon btn-active-color-primary w-30px h-30px ms-n2 me-3" id="header_menu_toggle">
        <span class="svg-icon svg-icon-1">
        <?=svg('header_menu_toggle');?>
        </span>
      </div>
      <a class="page-title" href="index.php">
        <img alt="Logo" src="<?=$logo_url;?>" class="h-40px h-lg-60px me-5" />
        <h1 class="text-dark fw-bolder d-inline-block my-1 fs-3 lh-1"><?=$website_name;?></h1>
      </a>
    </div>
    <div class="d-flex align-items-center">
      <?php include ('inc/templates/header/user_block.php');?>
    </div>
  </div>
  <div class="separator"></div>
  <div class="header-menu-container container-xxl d-flex flex-stack h-lg-75px" id="header_nav">
    <div class="header-menu flex-column flex-lg-row" data-drawer="true" data-drawer-name="header-menu" data-drawer-activate="{default: true, lg: false}" data-drawer-overlay="true" data-drawer-width="{default:'200px', '300px': '250px'}" data-drawer-direction="start" data-drawer-toggle="#header_menu_toggle" data-kt-swapper="true" data-kt-swapper-mode="prepend" data-kt-swapper-parent="{default: '#kt_body', lg: '#header_nav'}">
      <div class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch flex-grow-1" id="#header_menu" data-menu="true">
        <div class="menu-item"><a class="menu-link py-3 <?= ($activePage == 'index') ? 'active':''; ?>" href="index.php"><span class="menu-title"><?=lang('home');?></span></a></div>
        <div data-menu-trigger="click" data-menu-placement="bottom-start" class="menu-item menu-lg-down-accordion me-lg-1">
          <span class="menu-link py-3">
          <span class="menu-title"><?=lang('categories');?></span>
          <span class="menu-arrow d-lg-none"></span>
          </span>
          <div class="menu-sub menu-sub-lg-down-accordion menu-sub-lg-dropdown menu-rounded-0 py-lg-4 w-lg-225px">
            <?php header_getCategories();?>
          </div>
        </div>
        <div class="menu-item"><a class="menu-link py-3 <?= ($activePage == 'items') ? 'active':''; ?>" href="items.php"><span class="menu-title"><?=lang('items');?></span></a></div>
      </div>
      <?php if (!(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true)) { ?>
      <a class="btn btn-primary btn-hover-success me-2 ms-2" href="login.php"><?=lang('login');?></a><span class="d-inline-block m-auto"><?=lang('or');?></span><a class="btn btn-primary btn-hover-success me-2 ms-2" href="register.php"><?=lang('register');?></a>
      <?php } ?>
	  <?php if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true && $_SESSION['user_type'] == "admin") { ?>
	  <div class="flex-shrink-0 p-4 p-lg-0 me-lg-2">
  <a href="admin.php" class="btn btn-sm btn-light-success fw-bolder w-100 w-lg-auto <?= ($activePage == 'admin') ? 'active':''; ?>"><?=lang('admin_panel');?></a>
</div>
	  <?php } ?>
    </div>
  </div>
</div>