<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="shortcut icon" href="<?=$favicon_url;?>" />
<!-- Google Font -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" />
<!-- Plugins Stylesheet -->
<link href="assets/plugins/plugins.bundle.css" rel="stylesheet" type="text/css" />

<?php include 'inc/functions/cookies.php'; ?>
<!-- Custom and Boostrap 5 Stylesheet -->
<?php 
if (isset($_COOKIE['mode']) && $_COOKIE['mode'] == "light") {
	echo "<link href='assets/css/style.bundle.css' rel='stylesheet' type='text/css' />";
}
elseif (isset($_COOKIE['mode']) && $_COOKIE['mode'] == "dark") {
	echo "<link href='assets/css/style.dark.bundle.css' rel='stylesheet' type='text/css' />";
}
else {
	echo "<link href='assets/css/style.bundle.css' rel='stylesheet' type='text/css' />";
}