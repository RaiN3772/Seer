<?php
  if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) { ?>
<div class="d-flex align-items-center flex-shrink-0">
  <div class="d-flex align-items-center w-lg-225px">
    <form class="d-none d-lg-block w-100 mb-5 mb-lg-0 position-relative" autocomplete="off">
      <span class="svg-icon svg-icon-2 svg-icon-gray-700 position-absolute top-50 translate-middle-y ms-4">
      <?=svg('header_menu_search');?>
      </span>
      <input type="text" class="form-control bg-transparent ps-13 fs-7 h-40px" name="search" value="" placeholder="<?=lang('quick_search');?>" />
    </form>
  </div>
  <div class="d-flex align-items-center ms-3 ms-lg-4" id="kt_header_user_menu_toggle">
    <div class="btn btn-icon btn-color-gray-700 btn-active-color-primary btn-outline btn-outline-secondary w-30px h-30px w-lg-40px h-lg-40px" data-menu-trigger="click" data-menu-attach="parent" data-menu-placement="bottom-end">
      <span class="svg-icon svg-icon-1">
        <svg width='24' height='24' viewBox='0 0 24 24' fill='none'>
          <path d='M6.28548 15.0861C7.34369 13.1814 9.35142 12 11.5304 12H12.4696C14.6486 12 16.6563 13.1814 17.7145 15.0861L19.3493 18.0287C20.0899 19.3618 19.1259 21 17.601 21H6.39903C4.87406 21 3.91012 19.3618 4.65071 18.0287L6.28548 15.0861Z' fill='black' />
          <rect opacity='0.3' x='8' y='3' width='8' height='8' rx='4' fill='black' />
        </svg>
      </span>
    </div>
    <div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-800 menu-state-bg menu-state-primary fw-bold py-4 fs-6 w-275px" data-menu="true">
      <div class="menu-item px-3">
        <div class="menu-content d-flex align-items-center px-3">
          <div class="symbol symbol-50px me-5">
            <img alt="<?=$username;?>" src="<?=$useravatar;?>" />
          </div>
          <div class="d-flex flex-column">
            <div class="fw-bolder d-flex align-items-center fs-5"><?=$username;?>
              <span class="badge badge-light-success fw-bolder fs-8 px-2 py-1 ms-2 text-capitalize"><?=$usertype;?></span>
            </div>
            <span class="fw-bold text-muted fs-7"><?=$usertitle;?></span>
          </div>
        </div>
      </div>
      <div class="separator my-2"></div>
      <div class="menu-item px-5"><a href="profile.php?id=<?=$uid;?>" class="menu-link px-5"><?=lang('profile');?></a></div>
      <div class="menu-item px-5"><a href="settings.php" class="menu-link px-5"><?=lang('settings');?></a></div>
      <div class="separator my-2"></div>
      <div class="menu-item px-5"><a href="upload_item.php" class="menu-link px-5"><?=lang('upload');?></a></div>
      <?php if ($usertype == "admin") { ?>
      <div class="separator my-2"></div>
      <div class="menu-item px-5"><a href="admin.php" class="menu-link px-5"><?=lang('admin_panel');?></a></div>
      <?php } ?>
      <div class="separator my-2"></div>

      <div class="menu-item px-5" data-menu-trigger="hover" data-menu-placement="left-start">
        <a href="#" class="menu-link px-5">
        <span class="menu-title position-relative"><?=lang('language');?>
        <span class="fs-8 rounded bg-light px-3 py-2 position-absolute translate-middle-y top-50 end-0">English
        <img class="w-15px h-15px rounded-1 ms-2" src="assets/images/united-states.svg" /></span></span>
        </a>
        <div class="menu-sub menu-sub-dropdown w-175px py-4">
          <div class="menu-item px-3">
            <a href="#" class="menu-link d-flex px-5 active">
            <span class="symbol symbol-20px me-4">
            <img class="rounded-1" src="assets/images/united-states.svg" />
            </span>English</a>
          </div>
          <div class="menu-item px-3">
            <a href="#" class="menu-link d-flex px-5">
            <span class="symbol symbol-20px me-4">
            <img class="rounded-1" src="assets/images/palestine.svg" />
            </span>Arabic</a>
          </div>
        </div>
      </div>
	  <div class="separator my-2"></div>
      <div class="menu-item px-5">
        <a id="logout" href="logout.php" class="menu-link px-5"><?=lang('logout');?></a>
      </div>
      
    </div>
  </div>
  <!-- Support System - Deactivate for now -->
  <!--
    <div class="d-flex align-items-center ms-3 ms-lg-4">
      <div class="btn btn-icon btn-primary position-relative w-30px h-30px w-lg-40px h-lg-40px" id="kt_drawer_chat_toggle">3<span class="d-none bullet bullet-dot bg-danger h-6px w-6px position-absolute translate-middle top-0 start-50 animation-blink"></span></div>
    </div>
    -->
  <!--
    <button class="d-lg-none btn btn-icon btn-active-color-primary w-30px h-30px ms-2 me-n2" id="kt_aside_toggle">
    	<span class="svg-icon svg-icon-2">
    		<svg width="16" height="15" viewBox="0 0 16 15" fill="none">
    			<rect y="6" width="16" height="3" rx="1.5" fill="black" />
    			<rect opacity="0.3" y="12" width="8" height="3" rx="1.5" fill="black" />
    			<rect opacity="0.3" width="12" height="3" rx="1.5" fill="black" />
    		</svg>
    	</span>
    </button>
    -->
</div>
<?php } ?>