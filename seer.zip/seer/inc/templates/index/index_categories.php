<div class="col-l-12">
  <ul class="nav row">
    <li class="nav-item col-12 col-lg mb-5 mb-lg-0">
      <a class="nav-link btn btn-flex btn-color-gray-400 btn-outline btn-outline-default btn-active-primary d-flex flex-grow-1 flex-column flex-center py-5 h-1250px h-lg-175px" data-bs-toggle="tab" href="#">
        <span class="svg-icon svg-icon-3x mb-5 mx-0">
          <?=svg('category_icon');?>
        </span>
        <span class="fs-6 fw-bold">Category #1</span>
      </a>
    </li>
    <li class="nav-item col-12 col-lg mb-5 mb-lg-0">
      <a class="nav-link btn btn-flex btn-color-gray-400 btn-outline btn-outline-default btn-active-primary d-flex flex-grow-1 flex-column flex-center py-5 h-1250px h-lg-175px" data-bs-toggle="tab" href="#">
        <span class="svg-icon svg-icon-3x mb-5 mx-0">
          <?=svg('category_icon');?>
        </span>
        <span class="fs-6 fw-bold">Category #2</span>
      </a>
    </li>
    <li class="nav-item col-12 col-lg mb-5 mb-lg-0">
      <a class="nav-link btn btn-flex btn-color-gray-400 btn-outline btn-outline-default btn-active-primary d-flex flex-grow-1 flex-column flex-center py-5 h-1250px h-lg-175px active" data-bs-toggle="tab" href="#">
        <span class="svg-icon svg-icon-3x mb-5 mx-0">
          <?=svg('category_icon');?>
        </span>
        <span class="fs-6 fw-bold">Category #3</span>
      </a>
    </li>
    <li class="nav-item col-12 col-lg mb-5 mb-lg-0">
      <a class="nav-link btn btn-flex btn-color-gray-400 btn-outline btn-outline-default btn-active-primary d-flex flex-grow-1 flex-column flex-center py-5 h-1250px h-lg-175px" data-bs-toggle="tab" href="#">
        <span class="svg-icon svg-icon-3x mb-5 mx-0">
          <?=svg('category_icon');?>
        </span>
        <span class="fs-6 fw-bold">Category #4</span>
      </a>
    </li>
    <li class="nav-item col-12 col-lg mb-5 mb-lg-0">
      <a class="nav-link btn btn-flex btn-color-gray-400 btn-outline btn-outline-default btn-active-primary d-flex flex-grow-1 flex-column flex-center py-5 h-1250px h-lg-175px" data-bs-toggle="tab" href="#">
        <span class="svg-icon svg-icon-3x mb-5 mx-0">
          <?=svg('category_icon');?>
        </span>
        <span class="fs-6 fw-bold">Category #5</span>
      </a>
    </li>
  </ul>
</div>