<div class="toolbar py-5 py-lg-5" id="kt_toolbar">
  <div id="kt_toolbar_container" class="container-xxl py-5">
    <div class="row gy-0 gx-10">
      <div class="col-xl-12">
        <div class="card card-xl-stretch bg-body border-0 mb-5 mb-xl-0">
          <div class="card-body d-flex flex-column flex-lg-row flex-stack p-lg-15">
            <div class="d-flex flex-column justify-content-center align-items-center align-items-lg-start me-10 text-center text-lg-start">
              <h3 class="fs-2hx line-height-lg mb-5">
                <span class="fw-bold"><?=lang('toolbar_title');?></span><span class="fw-bolder"><?=lang('seller');?></span>
              </h3>
              <div class="fs-4 text-muted mb-7"><?=lang('toolbar_description');?><?=$website_name;?>.</div>
              <?php 
                if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) { ?>
              <a href="upload_item.php" class="btn btn-success fw-bold px-6 py-3"><?=lang('upload_your_work');?></a>
              <?php } else { ?>
              <a href="register.php" class="btn btn-success fw-bold px-6 py-3"><?=lang('sign_up_now');?></a>
              <?php }?>
            </div>
            <img src="assets/images/index_header.png" alt="" class="mw-200px mw-lg-350px mt-lg-n10">
          </div>
        </div>
      </div>
    </div>
  </div>
</div>