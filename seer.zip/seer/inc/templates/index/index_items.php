<h1 class="d-flex align-items-center my-1"><span class="text-dark fw-bolder fs-1">Featured Items</span></h1>
<?php index_getItems();?>