<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl mt-5">
  <div class="content flex-row-fluid" id="kt_content">
    <div class="card mb-6 mb-xl-9">
      <div class="card-body pt-9 pb-0">
        <div class="d-flex flex-wrap flex-sm-nowrap mb-6">
          <div class="d-flex flex-center flex-shrink-0 w-150px h-150px me-7 mb-4">
            <img class="mw-100 mh-100 rounded" src="<?=$item_thumbnail;?>">
          </div>
          <div class="flex-grow-1">
            <div class="d-flex justify-content-between align-items-start flex-wrap mb-2">
              <div class="d-flex flex-column">
                <div class="d-flex align-items-center mb-1">
                  <a href="#" class="text-gray-800 text-hover-primary fs-2 fw-bolder me-3"><?=$item_name;?></a>
                  <span class="badge badge-light-success me-auto"><?=$item_category;?></span>
                </div>
                <div class="d-flex flex-wrap fw-bold mb-4 fs-5 text-gray-400"><?=$item_short_description;?></div>
                <div class="d-flex flex-wrap fw-bold mb-4 fs-5 text-gray-400">
                  <div class="rating">
                    <input class="rating-input" name="rating" value="0" checked type="radio" id="kt_rating_input_0"/>
                    <label class="rating-label" for="kt_rating_input_1"><span class="svg-icon svg-icon-1"><?=svg('rating_star');?></span></label>
                    <input class="rating-input" name="rating" value="1" type="radio" id="kt_rating_input_1"/>
                    <label class="rating-label" for="kt_rating_input_2"><span class="svg-icon svg-icon-1"><?=svg('rating_star');?></span></label>
                    <input class="rating-input" name="rating" value="2" type="radio" id="kt_rating_input_2"/>
                    <label class="rating-label" for="kt_rating_input_3"><span class="svg-icon svg-icon-1"><?=svg('rating_star');?></span></label>
                    <input class="rating-input" name="rating" value="3" type="radio" id="kt_rating_input_3"/>
                    <label class="rating-label" for="kt_rating_input_4"><span class="svg-icon svg-icon-1"><?=svg('rating_star');?></span></label>
                    <input class="rating-input" name="rating" value="4" type="radio" id="kt_rating_input_4"/>
                    <label class="rating-label" for="kt_rating_input_5"><span class="svg-icon svg-icon-1"><?=svg('rating_star');?></span></label>
                    <input class="rating-input" name="rating" value="5" type="radio" id="kt_rating_input_5"/>
                  </div>
                </div>
              </div>
            </div>
            <div class="d-flex flex-wrap justify-content-start">
              <div class="d-flex flex-wrap">
                <div class="border border-gray-300 border-dashed rounded min-w-125px py-3 px-4 me-6 mb-3">
                  <div class="d-flex align-items-center">
                    <div class="fs-4 fw-bolder"><?=$item_upload_time;?></div>
                  </div>
                  <div class="fw-bold fs-6 text-gray-400"><?=lang('first_release');?></div>
                </div>
                <?php if ($item_edit_time != NULL) { ?>
                <div class="border border-gray-300 border-dashed rounded min-w-125px py-3 px-4 me-6 mb-3">
                  <div class="d-flex align-items-center">
                    <div class="fs-4 fw-bolder"><?=$item_edit_time;?></div>
                  </div>
                  <div class="fw-bold fs-6 text-gray-400"><?=lang('last_updated');?></div>
                </div>
                <?php } ?>
                <!--
                  <div class="border border-gray-300 border-dashed rounded min-w-125px py-3 px-4 me-6 mb-3">
                    <div class="d-flex align-items-center">
                      <span class="svg-icon svg-icon-3 svg-icon-success me-2">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                          <rect opacity="0.5" x="13" y="6" width="13" height="2" rx="1" transform="rotate(90 13 6)" fill="black"></rect>
                          <path d="M12.5657 8.56569L16.75 12.75C17.1642 13.1642 17.8358 13.1642 18.25 12.75C18.6642 12.3358 18.6642 11.6642 18.25 11.25L12.7071 5.70711C12.3166 5.31658 11.6834 5.31658 11.2929 5.70711L5.75 11.25C5.33579 11.6642 5.33579 12.3358 5.75 12.75C6.16421 13.1642 6.83579 13.1642 7.25 12.75L11.4343 8.56569C11.7467 8.25327 12.2533 8.25327 12.5657 8.56569Z" fill="black"></path>
                        </svg>
                      </span>
                      <div class="fs-4 fw-bolder" data-kt-countup="true" data-kt-countup-value="15000" data-kt-countup-prefix="$">$15,000</div>
                    </div>
                    <div class="fw-bold fs-6 text-gray-400">Sales</div>
                  </div>
				  -->
                  <div class="border border-gray-300 border-dashed rounded min-w-125px py-3 px-4 me-6 mb-3">
                    <div class="d-flex align-items-center">
                      <span class="svg-icon svg-icon-3 svg-icon-success me-2">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                          <rect opacity="0.5" x="13" y="6" width="13" height="2" rx="1" transform="rotate(90 13 6)" fill="black"></rect>
                          <path d="M12.5657 8.56569L16.75 12.75C17.1642 13.1642 17.8358 13.1642 18.25 12.75C18.6642 12.3358 18.6642 11.6642 18.25 11.25L12.7071 5.70711C12.3166 5.31658 11.6834 5.31658 11.2929 5.70711L5.75 11.25C5.33579 11.6642 5.33579 12.3358 5.75 12.75C6.16421 13.1642 6.83579 13.1642 7.25 12.75L11.4343 8.56569C11.7467 8.25327 12.2533 8.25327 12.5657 8.56569Z" fill="black"></path>
                        </svg>
                      </span>
                      <div class="fs-4 fw-bolder" data-kt-countup="true" data-kt-countup-value="<?=$feedbacks_counter;?>"><?=$feedbacks_counter;?></div>
                    </div>
                    <div class="fw-bold fs-6 text-gray-400"><?=lang('feedbacks');?></div>
                  </div>
                  
              </div>
            </div>
          </div>
        </div>
        <div class="separator"></div>
        <div class="d-flex overflow-auto h-55px">
          <ul class="nav nav-stretch nav-line-tabs nav-line-tabs-2x border-transparent fs-5 fw-bolder flex-nowrap">
            <li class="nav-item"><a class="nav-link text-active-primary me-6 <?=isset($_GET['id']) ? "active" : "" ?>" href="?id=<?=$item_id;?>"><?=lang('overview');?></a></li>
            <li class="nav-item"><a class="nav-link text-active-primary me-6 <?=isset($_GET['feedback']) ? "active" : "" ?>" href="?feedback=<?=$item_id;?>"><?=lang('feedback');?></a></li>
            <?php if ($item_uid == $uid || $usertype == "admin") {?>
            <li class="nav-item"><a class="nav-link text-active-primary me-6 <?=isset($_GET['edit']) ? "active" : "" ?>" href="?edit=<?=$item_id;?>"><?=lang('edit');?></a></li>
            <?php } ?>
          </ul>
        </div>
      </div>
    </div>
    <?php 
      if (isset($_GET['edit'])) {
		  include "inc/templates/items/item_edit.php";
      }
      elseif (isset($_GET['feedback'])) { 
		  include "inc/templates/items/item_feedback.php";
      }
      else {
    ?>
    <div class="d-flex flex-column flex-lg-row">
      <div class="flex-lg-row-fluid me-lg-15 order-2 order-lg-1 mb-10 mb-lg-0">
        <div class="card card-flush bg-light pt-3 mb-5 mb-xl-10">
          <div class="card-header">
            <div class="card-title">
              <h2 class="fw-bolder"><?=lang('overview');?></h2>
            </div>
          </div>
          <div class="card-body pt-3">
            <?=nl2br($item_description);?>
          </div>
        </div>
        <?php if ($item_features != NULL) {?>
        <div class="card card-flush bg-light pt-3 mb-5 mb-xl-10">
          <div class="card-header">
            <div class="card-title">
              <h2 class="fw-bolder"><?=lang('features');?></h2>
            </div>
          </div>
          <div class="card-body pt-3">
            <?=nl2br($item_features);?>
          </div>
        </div>
        <?php } ?>
        <?php if ($item_requirements != NULL) {?>
        <div class="card card-flush bg-light pt-3 mb-5 mb-xl-10">
          <div class="card-header">
            <div class="card-title">
              <h2 class="fw-bolder"><?=lang('requirements');?></h2>
            </div>
          </div>
          <div class="card-body pt-3">
            <?=nl2br($item_requirements);?>
          </div>
        </div>
        <?php } ?>
      </div>
      <div class="flex-column flex-lg-row-auto w-lg-250px w-xl-300px mb-10 order-1 order-lg-2">
        <div class="card card-flush mb-0" data-kt-sticky="true" data-kt-sticky-offset="{default: false, lg: '200px'}" data-kt-sticky-width="{lg: '250px', xl: '300px'}" data-kt-sticky-left="auto" data-kt-sticky-top="150px" data-kt-sticky-animation="false" data-kt-sticky-zindex="95">
          <div class="card-header">
            <div class="card-title">
              <h2><?=lang('information');?></h2>
            </div>
            <div class="card-toolbar">
              <span href="#" class="btn btn-sm btn-primary">$<?=$item_price;?></span>
            </div>
          </div>
          <div class="card-body pt-0 fs-6">
            <div class="mb-7">
              <div class="d-flex align-items-center">
                <div class="symbol symbol-60px symbol-circle me-3">
                  <img src="<?=$item_useravatar;?>">
                </div>
                <div class="d-flex flex-column">
                  <a href="profile.php?id=<?=$item_uid;?>" class="fs-4 fw-bolder text-gray-900 text-hover-primary me-2"><?=$item_username;?></a>
                  <span href="#" class="fw-bold text-gray-600 text-hover-primary item-email"><?=$item_useremail;?></span>
                </div>
              </div>
            </div>
            <div class="separator separator-dashed mb-7"></div>
            <div class="mb-10">
              <h5 class="mb-4"><?=lang('payment_details');?></h5>
              <div class="mb-0">
                <div class="fw-bold text-gray-600 d-flex align-items-center">Mastercard 
                  <img src="assets/images/mastercard.svg" class="w-35px ms-2" alt="">
                </div>
                <div class="fw-bold text-gray-600">Expires Dec 2024</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php } ?>
  </div>
</div>