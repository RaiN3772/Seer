<?php
  include 'inc/functions/items/edit_item.php';
  if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true && ($_SESSION['uid'] == $item_uid || $_SESSION['user_type'] == "admin")) { ?>
<div class="card">
  <div class="card-header">
    <div class="card-title fs-3 fw-bolder"><?=lang('edit');?> <?=$item_name;?></div>
  </div>
  <form class="form" action="item.php?edit=<?=$item_id;?>" method="post"  enctype="multipart/form-data">
    <div class="card-body p-9">
      <div class="row mb-5">
        <div class="col-xl-3">
          <div class="fs-6 fw-bold mt-2 mb-3"><?=lang('item_thumbnail');?></div>
        </div>
        <div class="col-lg-8">
          <div class="image-input image-input-outline" data-kt-image-input="true" style="background-image: url('assets/media/avatars/blank.png')">
            <div class="image-input-wrapper w-125px h-125px bgi-position-center" style="background-image: url('<?=$item_thumbnail;?>')"></div>
            <label class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-white shadow" data-kt-image-input-action="change" data-bs-toggle="tooltip" title="Change Thumbnail">
            <i class="bi bi-pencil-fill fs-7"></i>
            <input type="file" name="item_thumbnail" accept=".png, .jpg, .jpeg" disabled>
            </label>
          </div>
          <div class="form-text"><?=lang('allowed_files_thumbnail');?></div>
          <div class="fv-plugins-message-container invalid-feedback"><?=$itemThumbnailError;?></div>
        </div>
      </div>
      <div class="row mb-8">
        <div class="col-xl-3">
          <div class="fs-6 fw-bold mt-2 mb-3"><?=lang('item_name');?></div>
        </div>
        <div class="col-xl-9 fv-row">
          <input type="text" class="form-control form-control-solid" name="item_name" value="<?=$item_name;?>">
          <div class="fv-plugins-message-container invalid-feedback"><?=$itemNameError;?></div>
        </div>
      </div>
      <div class="row mb-8">
        <div class="col-xl-3">
          <div class="fs-6 fw-bold mt-2 mb-3"><?=lang('item_short_description');?></div>
        </div>
        <div class="col-xl-9 fv-row">
          <input type="text" class="form-control form-control-solid" name="item_short_description" value="<?=$item_short_description;?>">
          <div class="form-text"><?=lang('short_description_max');?></div>
          <div class="fv-plugins-message-container invalid-feedback"><?=$itemShortDescriptionError;?></div>
        </div>
      </div>
      <div class="row mb-8">
        <div class="col-xl-3">
          <div class="fs-6 fw-bold mt-2 mb-3"><?=lang('item_description');?></div>
        </div>
        <div class="col-xl-9 fv-row">
          <textarea name="item_description" class="form-control form-control-solid h-100px"><?=$item_description;?></textarea>
          <div class="fv-plugins-message-container invalid-feedback"><?=$itemDescriptionError;?></div>
        </div>
      </div>
      <div class="row mb-8">
        <div class="col-xl-3">
          <div class="fs-6 fw-bold mt-2 mb-3"><?=lang('item_features');?></div>
        </div>
        <div class="col-xl-9 fv-row">
          <textarea name="item_features" class="form-control form-control-solid h-100px"><?=$item_features;?></textarea>
        </div>
      </div>
      <div class="row mb-8">
        <div class="col-xl-3">
          <div class="fs-6 fw-bold mt-2 mb-3"><?=lang('item_requirements');?></div>
        </div>
        <div class="col-xl-9 fv-row">
          <textarea name="item_requirements" class="form-control form-control-solid h-100px"><?=$item_requirements;?></textarea>
        </div>
      </div>
      <div class="row mb-8">
        <div class="col-xl-3">
          <div class="fs-6 fw-bold mt-2 mb-3"><?=lang('item_price');?></div>
        </div>
        <div class="col-xl-9 fv-row">
          <input type="number" class="form-control form-control-solid" name="item_price" value="<?=$item_price;?>">
          <div class="fv-plugins-message-container invalid-feedback"><?=$itemPriceError;?></div>
        </div>
      </div>
      <div class="row mb-8">
        <div class="col-xl-3">
          <div class="fs-6 fw-bold mt-2 mb-3"><?=lang('item_main_file');?></div>
        </div>
        <div class="col-xl-9 fv-row">
          <input type="file" class="form-control form-control-solid" name="item_file" disabled>
        </div>
      </div>
    </div>
    <div class="card-footer d-flex justify-content-end py-6 px-9">
      <button type="submit" class="btn btn-primary"><?=lang('save_changes');?></button>
    </div>
  </form>
</div>
<?php } else {
  echo "<script type='text/javascript'>window.location.href = 'item.php?id=$item_id';</script>";
  }	?>