<?php 
include 'inc/functions/items/item_feedback.php';
 if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) { 
?>
<div class="card mb-5 mb-xl-8">
  <div class="card-body pb-0">
    <div class="d-flex align-items-center">
      <div class="d-flex align-items-center flex-grow-1">
        <div class="symbol symbol-45px me-5">
          <img src="<?=$useravatar;?>">
        </div>
        <div class="d-flex flex-column">
          <span class="text-gray-900 fs-6 fw-bolder"><?=$username;?></span>
          <span class="text-gray-400 fw-bold"><?=$usertitle;?></span>
        </div>
      </div>
    </div>
    <form class="bg-transparent border-transparent" method="post" action="item.php?feedback=<?=$item_id;?>">
      <textarea name="feedback_post" class="form-control bg-transparent border-transparent mt-5 mb-5" id="feedback" rows="1" placeholder="What is on your mind?" maxlength="<?=$feedback_max_length;?>" data-kt-autosize="true"></textarea>
	  <div class="fv-plugins-message-container invalid-feedback"><?=$feedbackError;?></div>
      <div class="separator mb-5"></div>
	  <button type="submit" href="#" class="btn btn-sm btn-light btn-color-muted btn-active-light-danger px-4 py-2 mb-5" style="float: right;">Post</button>
    </form>
  </div>
</div>
 <?php }
item_getFeedbacks(); ?>
