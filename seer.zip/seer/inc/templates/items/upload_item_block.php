<div class="stepper stepper-pills" id="upload_item">
  <div class="stepper-nav flex-center flex-wrap mb-10">
    <div class="stepper-item mx-2 my-4 current" data-kt-stepper-element="nav" data-kt-stepper-action="step">
      <div class="stepper-line w-40px"></div>
      <div class="stepper-icon w-40px h-40px"><i class="stepper-check fas fa-check"></i><span class="stepper-number">1</span></div>
      <div class="stepper-label">
        <h3 class="stepper-title"><?=lang('step_one');?></h3>
        <div class="stepper-desc"><?=lang('category');?></div>
      </div>
    </div>
    <div class="stepper-item mx-2 my-4" data-kt-stepper-element="nav" data-kt-stepper-action="step">
      <div class="stepper-line w-40px"></div>
      <div class="stepper-icon w-40px h-40px"><i class="stepper-check fas fa-check"></i><span class="stepper-number">2</span></div>
      <div class="stepper-label">
        <h3 class="stepper-title"><?=lang('step_two');?></h3>
        <div class="stepper-desc"><?=lang('description');?></div>
      </div>
    </div>
    <div class="stepper-item mx-2 my-4" data-kt-stepper-element="nav" data-kt-stepper-action="step">
      <div class="stepper-line w-40px"></div>
      <div class="stepper-icon w-40px h-40px"><i class="stepper-check fas fa-check"></i><span class="stepper-number">3</span></div>
      <div class="stepper-label">
        <h3 class="stepper-title"><?=lang('step_three');?></h3>
        <div class="stepper-desc"><?=lang('files');?></div>
      </div>
    </div>
    <div class="stepper-item mx-2 my-4" data-kt-stepper-element="nav" data-kt-stepper-action="step">
      <div class="stepper-line w-40px"></div>
      <div class="stepper-icon w-40px h-40px"><i class="stepper-check fas fa-check"></i><span class="stepper-number">4</span></div>
      <div class="stepper-label">
        <h3 class="stepper-title"><?=lang('step_four');?></h3>
        <div class="stepper-desc"><?=lang('submit');?></div>
      </div>
    </div>
  </div>
  <form class="form w-lg-500px mx-auto" novalidate="novalidate" id="kt_stepper_example_basic_form"  action="<?=htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post"  enctype="multipart/form-data">
    <div class="mb-5">
      <div class="flex-column current" data-kt-stepper-element="content">
        <div class="w-100">
          <div class="pb-7 pb-lg-12">
            <h1 class="fw-bolder text-dark"><?=lang('item_category');?></h1>
            <span class="text-muted fw-bold fs-4"><?=lang('select_category');?></span>
          </div>
          <div class="fv-row mb-15 fv-plugins-icon-container fv-plugins-bootstrap5-row-valid" data-kt-buttons="true">
            <?php upload_getCategories(); ?>
            <div class="fv-plugins-message-container invalid-feedback"><?=$itemCategoryError;?></div>
          </div>
        </div>
      </div>
      <div class="flex-column" data-kt-stepper-element="content">
        <div class="fv-row mb-10">
          <div class="input-group input-group-solid">
            <span class="input-group-text" id="basic-addon1"><?=lang('name');?></span>
            <input type="text" class="form-control required" placeholder="Enter Item Name" name="item_name" value="<?=$itemName;?>"/>
          </div>
          <div class="fv-plugins-message-container invalid-feedback"><?=$itemNameError;?></div>
        </div>
        <div class="fv-row mb-10">
          <label class="form-label d-flex align-items-center">
          <span class="required"><?=lang('short_description');?></span>
          <i class="fas fa-exclamation-circle ms-2 fs-7" data-bs-toggle="tooltip" title="Maximum 130 characters"></i>
          </label>
          <input type="text" class="form-control form-control-solid" name="item_short_description" placeholder="Enter a short description for the item" value="<?=$itemShortDescription;?>"/>
          <div class="fv-plugins-message-container invalid-feedback"><?=$itemShortDescriptionError;?></div>
        </div>
        <div class="fv-row mb-10">
          <label class="form-label d-flex align-items-center">
          <span class="required"><?=lang('description');?></span>
          <i class="fas fa-exclamation-circle ms-2 fs-7" data-bs-toggle="tooltip" title="Enter a detailed description about your item"></i>
          </label>
          <textarea class="form-control form-control-solid" rows="4" placeholder="Enter a detailed description about your item" name="item_description"><?=$itemDescription;?></textarea>
          <div class="fv-plugins-message-container invalid-feedback"><?=$itemDescriptionError;?></div>
        </div>
        <div class="fv-row mb-10">
          <label class="form-label d-flex align-items-center">
          <?=lang('features');?>
          <i class="fas fa-exclamation-circle ms-2 fs-7" data-bs-toggle="tooltip" title="Enter a list of features"></i>
          </label>
          <textarea class="form-control form-control-solid" rows="4" placeholder="Enter a list of features" name="item_features"><?=$itemFeatures;?></textarea>
        </div>
        <div class="fv-row mb-10">
          <label class="form-label d-flex align-items-center">
          <?=lang('requirements');?>
          <i class="fas fa-exclamation-circle ms-2 fs-7" data-bs-toggle="tooltip" title="Enter a list of requirements"></i>
          </label>
          <textarea class="form-control form-control-solid" rows="4" placeholder="Enter a list of requirements" name="item_requirements"><?=$itemRequirements;?></textarea>
        </div>
        <div class="fv-row mb-8 fv-plugins-icon-container">
          <label class="d-flex align-items-center fs-6 fw-bold mb-2">
          <span class="required"><?=lang('item_price');?></span>
          </label>
          <div class="position-relative w-lg-250px" id="modal_upload_item_price_setup" data-kt-dialer="true" data-kt-dialer-min="0" data-kt-dialer-max="300" data-kt-dialer-step="2" data-kt-dialer-decimals="2">
            <button type="button" class="btn btn-icon btn-active-color-gray-700 position-absolute translate-middle-y top-50 start-0" data-kt-dialer-control="decrease">
              <span class="svg-icon svg-icon-1">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                  <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="10" fill="black"></rect>
                  <rect x="6.01041" y="10.9247" width="12" height="2" rx="1" fill="black"></rect>
                </svg>
              </span>
            </button>
            <input type="text" class="form-control form-control-solid border-0 ps-12" data-kt-dialer-control="input" placeholder="Amount" name="item_price">
            <button type="button" class="btn btn-icon btn-active-color-gray-700 position-absolute translate-middle-y top-50 end-0" data-kt-dialer-control="increase">
              <span class="svg-icon svg-icon-1">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                  <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="10" fill="black"></rect>
                  <rect x="10.8891" y="17.8033" width="12" height="2" rx="1" transform="rotate(-90 10.8891 17.8033)" fill="black"></rect>
                  <rect x="6.01041" y="10.9247" width="12" height="2" rx="1" fill="black"></rect>
                </svg>
              </span>
            </button>
            <div class="fv-plugins-message-container invalid-feedback"><?=$itemPriceError;?></div>
          </div>
        </div>
      </div>
      <div class="flex-column" data-kt-stepper-element="content">
        <div class="fv-row mb-10">
          <label class="form-label d-flex align-items-center">
          <span class="required"><?=lang('item_thumbnail');?></span>
          <i class="fas fa-exclamation-circle ms-2 fs-7" data-bs-toggle="tooltip" title="Please upload a thumbnail for the item"></i>
          </label>
          <input type="file" class="form-control form-control-solid" name="item_thumbnail">
          <div class="fv-plugins-message-container invalid-feedback"><?=$itemThumbnailError;?></div>
        </div>
        <div class="fv-row mb-10">
          <label class="form-label d-flex align-items-center">
          <span class="required"><?=lang('item_file');?></span>
          <i class="fas fa-exclamation-circle ms-2 fs-7" data-bs-toggle="tooltip" title="<?=lang('item_file_note');?>"></i>
          </label>
          <input type="file" class="form-control form-control-solid" name="item_file">
          <div class="fv-plugins-message-container invalid-feedback"><?=$itemFileError;?></div>
        </div>
      </div>
      <div class="flex-column" data-kt-stepper-element="content">
        <div class="pb-12 text-center">
          <h1 class="fw-bolder text-dark"><?=lang('submit_item');?></h1>
          <div class="text-muted fw-bold fs-4"><?=lang('submit_item_note');?></div>
          <img src="assets/images/upload_item.png" alt="" class="mww-100 mh-350px" />
        </div>
      </div>
    </div>
    <div class="d-flex flex-stack">
      <div class="me-2"><button type="button" class="btn btn-light btn-active-light-primary" data-kt-stepper-action="previous"><?=lang('back');?></button></div>
      <div>
        <button type="submit" class="btn btn-primary" data-kt-stepper-action="submit">
        <span class="indicator-label">
        <?=lang('submit');?>
        </span>
        <span class="indicator-progress">
        <?=lang('please_Wait');?> <span class="spinner-border spinner-border-sm align-middle ms-2"></span>
        </span>
        </button>
        <button type="button" class="btn btn-primary" data-kt-stepper-action="next">
        <?=lang('continue');?>
        </button>
      </div>
    </div>
  </form>
</div>