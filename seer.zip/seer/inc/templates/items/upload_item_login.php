<div class="card">
  <div class="card-body pb-0">
    <div class="card-px text-center pt-20 pb-5">
      <h2 class="fs-2x fw-bolder mb-0"><?=lang('toolbar_title');?> <?=lang('seller');?></h2>
      <p class="text-gray-400 fs-4 fw-bold py-7">
        <?=lang('upload_item_description_login');?>
      </p>
      <a href="login.php" class="btn btn-primary er fs-6 px-8 py-4"><?=lang('login');?></a>
    </div>
    <div class="text-center px-5">
      <img src="assets/media/illustrations/sketchy-1/6.png" alt="" class="mw-100 h-200px h-sm-325px" />
    </div>
  </div>
</div>