<div class="d-flex flex-column flex-column-fluid bgi-position-y-bottom position-x-center bgi-no-repeat bgi-size-contain bgi-attachment-fixed" style="background-image: url(assets/images/authentication.png)">
<div class="d-flex flex-center flex-column flex-column-fluid p-10 pb-lg-20">
  <a href="index.php" class="mb-12">
    <img alt="Logo" src="<?=$logo_url;?>" class="h-40px me-3" />
    <h1 class="text-dark fw-bolder d-inline-block my-1 fs-3 lh-1"><?=$website_name;?></h1>
  </a>
  <div class="w-lg-500px bg-body rounded shadow-sm p-10 p-lg-15 mx-auto">
    <form class="form w-100" novalidate="novalidate" id="sign_in_form" action="<?= htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
      <div class="text-center mb-10">
        <h1 class="text-dark mb-3"><?=lang('sign_in');?><?=$website_name;?></h1>
        <div class="text-gray-400 fw-bold fs-4"><?=lang('new_here');?><a href="register.php" class="link-primary fw-bolder"><?=lang('create_account');?></a></div>
      </div>
      <div class="fv-row mb-10">
        <label class="form-label fs-6 fw-bolder text-dark"><?=lang('username');?></label>
        <input class="form-control form-control-lg form-control-solid" type="text" name="username" id="username" value="<?=$username;?>" autocomplete="off" />
        <div class="fv-plugins-message-container invalid-feedback"><?=$usernameError;?></div>
      </div>
      <div class="fv-row mb-10">
        <div class="d-flex flex-stack mb-2">
          <label class="form-label fw-bolder text-dark fs-6 mb-0"><?=lang('password');?></label>
          <a href="#" class="link-primary fs-6 fw-bolder"><?=lang('forgot_password');?></a>
        </div>
        <input class="form-control form-control-lg form-control-solid" type="password" name="password" autocomplete="off" />
        <div class="fv-plugins-message-container invalid-feedback"><?=$passwordError;?></div>
      </div>
      <div class="text-center">
        <div id="toast"/>
          <button type="submit" id="sign_in_submit" class="btn btn-lg btn-primary w-100 mb-5">
          <span class="indicator-label"><?=lang('continue');?></span>
          <span class="indicator-progress"><?=lang('please_wait');?>
          <span class="spinner-border spinner-border-sm align-middle ms-2"></span>
          </span>
          </button>
          <div class="text-center text-muted text-uppercase fw-bolder mb-5"><?=lang('or');?></div>
          <a href="#" class="btn btn-flex flex-center btn-light btn-lg w-100 mb-5"><img alt="Logo" src="assets/images/google-icon.svg" class="h-20px me-3" /><?=lang('continue_google');?></a>
          <a href="#" class="btn btn-flex flex-center btn-light btn-lg w-100 mb-5"><img alt="Logo" src="assets/images/facebook-icon.svg" class="h-20px me-3" /><?=lang('continue_facebook');?></a>
        </div>
    </form>
    </div>
  </div>
  <div class="d-flex flex-center flex-column-auto p-10">
    <div class="d-flex align-items-center fw-bold fs-6">
      <a href="#" class="text-muted text-hover-primary px-2">Link #1</a>
      <a href="#" class="text-muted text-hover-primary px-2">Link #2</a>
      <a href="#" class="text-muted text-hover-primary px-2">Link #3</a>
    </div>
  </div>
</div>