<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl mt-5">
  <div class="content flex-row-fluid" id="kt_content">
    <div class="d-flex flex-column flex-lg-row">
      <div class="flex-column flex-lg-row-auto w-lg-250px w-xl-350px mb-10">
        <div class="card mb-5 mb-xl-8">
          <div class="card-body">
            <div class="d-flex flex-center flex-column py-5">
              <div class="symbol symbol-100px symbol-circle mb-7">
                <img src="<?=$profile_avatar;?>">
              </div>
              <a href="#" class="fs-3 text-gray-800 text-hover-primary fw-bolder mb-3"><?=$profile_name;?></a>
              <div class="mb-9">
                <div class="badge badge-lg badge-light-success d-inline"><?=$profile_type;?></div>
              </div>
              <div class="fw-bolder mb-3"><?=$profile_title;?></div>
            </div>
            <div class="d-flex flex-stack fs-4 py-3">
              <div class="fw-bolder rotate collapsible" data-bs-toggle="collapse" href="#kt_user_view_details" role="button" aria-expanded="true" aria-controls="kt_user_view_details">
                Details 
                <span class="ms-2 rotate-180">
                  <span class="svg-icon svg-icon-3">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                      <path d="M11.4343 12.7344L7.25 8.55005C6.83579 8.13583 6.16421 8.13584 5.75 8.55005C5.33579 8.96426 5.33579 9.63583 5.75 10.05L11.2929 15.5929C11.6834 15.9835 12.3166 15.9835 12.7071 15.5929L18.25 10.05C18.6642 9.63584 18.6642 8.96426 18.25 8.55005C17.8358 8.13584 17.1642 8.13584 16.75 8.55005L12.5657 12.7344C12.2533 13.0468 11.7467 13.0468 11.4343 12.7344Z" fill="black"></path>
                    </svg>
                  </span>
                </span>
              </div>
              <?php if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] == true && $_SESSION['user_type'] == "admin") {  ?><a href="admin.php?edit_user=<?=$profile_id;?>" title="Edit <?=$profile_name;?> details" data-bs-toggle="tooltip" class="btn btn-sm btn-primary">Edit</a><?php } ?>
            </div>
            <div class="separator"></div>
            <div id="kt_user_view_details" class="collapse show" style="">
              <div class="pb-5 fs-6">
                <?php if ($display_uid == 1) { ?>
				<div class="fw-bolder mt-5">User ID</div>
                <div class="text-gray-600">ID-<?=$profile_id;?></div>
				<?php } ?>
                <div class="fw-bolder mt-5">Email</div>
                <div class="text-gray-600">
                  <a href="#" class="text-gray-600 text-hover-primary"><?=$profile_email;?></a>
                </div>
				<?php if ($profile_lastlogin != NULL) { ?>
                <div class="fw-bolder mt-5">Last Login</div>
                <div class="text-gray-600"><?=$profile_lastlogin;?></div>
				<?php } ?>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="flex-lg-row-fluid ms-lg-15">
        <?php include 'inc/templates/profile/profile_Overview.php';?>
      </div>
    </div>
  </div>
</div>