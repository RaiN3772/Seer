<?php if ($profile_bio != NULL) { ?>
<div class="card mb-5 mb-xl-10">
  <div class="card-header">
    <div class="card-title m-0"><h3 class="fw-bolder m-0"><?=lang('about')?> <?=$profile_name;?></h3></div>
  </div>
  <div class="card-body p-9">
	<?=$profile_bio;?>
  </div>
</div>
<?php } ?>
<div class="card mb-5 mb-xl-10">
  <div class="card-header">
    <div class="card-title m-0">
      <h3 class="fw-bolder m-0"><?=lang('profile_details')?></h3>
    </div>
    <?php if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] == true && $_SESSION['uid'] == $profile_id) {  ?><a href="settings.php" class="btn btn-primary align-self-center">Edit Profile</a><?php } ?>
  </div>
  <div class="card-body p-9">
  <?php if ($profile_fullname != NULL) { ?>
    <div class="row mb-7">
      <label class="col-lg-4 fw-bold text-muted"><?=lang('full_name');?></label>
      <div class="col-lg-8"><span class="fw-bolder fs-6 text-gray-800"><?=$profile_fullname;?></span></div>
    </div>
  <?php } ?>
    <div class="row mb-7">
      <label class="col-lg-4 fw-bold text-muted"><?=lang('joined');?></label>
      <div class="col-lg-8 fv-row">
        <span class="fw-bold text-gray-800 fs-6"><?=$profile_register;?></span>
      </div>
    </div>
	<?php if ($profile_lastlogin != NULL) { ?>
    <div class="row mb-7">
      <label class="col-lg-4 fw-bold text-muted"><?=lang('last_login');?></label>
      <div class="col-lg-8"><span class="fw-bold fs-6 text-gray-800"><?=$profile_lastlogin;?></span></div>
    </div>
  <?php } ?>
  <?php if ($profile_website != NULL) { ?>
    <div class="row mb-7">
      <label class="col-lg-4 fw-bold text-muted"><?=lang('website');?></label>
      <div class="col-lg-8"><span class="fw-bold fs-6 text-gray-800"><a href="<?=$profile_website;?>" target="_blank"><?=$profile_website;?></a></span></div>
    </div>
  <?php } ?>
  <?php if ($profile_gender != NULL) { ?>
    <div class="row mb-7">
      <label class="col-lg-4 fw-bold text-muted"><?=lang('gender');?></label>
      <div class="col-lg-8"><span class="fw-bold fs-6 text-gray-800"><?=$profile_gender;?></span></div>
    </div>
  <?php } ?>
  <?php if ($profile_country != NULL) { ?>
    <div class="row mb-7">
      <label class="col-lg-4 fw-bold text-muted"><?=lang('country');?></label>
      <div class="col-lg-8"><span class="fw-bold fs-6 text-gray-800"><?=$profile_country;?></span></div>
    </div>
  <?php } ?>
  <?php if ($usertype == "admin") { ?>
  <div class="separator mb-5"></div>
  <div class="row mb-7">
      <label class="col-lg-4 fw-bold text-muted"><?=lang('registered_ip');?></label>
      <div class="col-lg-8 fv-row">
        <span class="fw-bold text-gray-800 fs-6"><?=$profile_registerip;?></span>
      </div>
    </div>
	<?php if ($profile_lastip != NULL) { ?>
	<div class="row mb-7">
      <label class="col-lg-4 fw-bold text-muted"><?=lang('last_ip');?></label>
      <div class="col-lg-8 fv-row">
        <span class="fw-bold text-gray-800 fs-6"><?=$profile_lastip;?></span>
      </div>
    </div>
  <?php } ?>
  <div class="separator mb-5"></div>
  <?php } ?>
  <?php if ($items_counter > 0) { ?>
  <div class="row mb-7">
      <label class="col-lg-4 fw-bold text-muted"><?=lang('total_items');?></label>
      <div class="col-lg-8 fv-row">
        <span class="fw-bold text-gray-800 fs-6"><?=$items_counter;?></span>
      </div>
    </div>
  <?php } ?>
  <?php if ($feedback_counter > 0) { ?>
  <div class="row mb-7">
      <label class="col-lg-4 fw-bold text-muted"><?=lang('total_feedbacks');?></label>
      <div class="col-lg-8 fv-row">
        <span class="fw-bold text-gray-800 fs-6"><?=$feedback_counter;?></span>
      </div>
    </div>
  <?php } ?>

  </div>
</div>
<?php  if ($items_counter > 0) { profile_getItems(); }?>