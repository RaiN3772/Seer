<div class="rounded border p-10 pb-0 d-flex flex-column flex-center">
<div class="alert bg-light-danger d-flex flex-center flex-column py-10 px-10 px-lg-20 mb-10">
  <span class="svg-icon svg-icon-5tx svg-icon-danger mb-5">
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
      <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="10" fill="black"></rect>
      <rect x="11" y="14" width="7" height="2" rx="1" transform="rotate(-90 11 14)" fill="black"></rect>
      <rect x="11" y="17" width="2" height="2" rx="1" transform="rotate(-90 11 17)" fill="black"></rect>
    </svg>
  </span>
  <div class="text-center">
    <h1 class="fw-bolder mb-5"><?=lang('access_denied');?></h1>
    <div class="separator separator-dashed border-danger opacity-25 mb-5"></div>
    <div class="mb-9 text-dark"><?=lang('private_profile');?></div>
    <div class="d-flex flex-center flex-wrap">
      <a href="login.php" class="btn btn-outline btn-outline-danger btn-active-danger m-2">Login Page</a>
      <a href="index.php" class="btn btn-danger m-2">Home Page</a>
    </div>
  </div>
</div>
</div>