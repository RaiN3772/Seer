<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl">
  <div class="content flex-row-fluid mt-5">
    <div class="card mb-5 mb-xl-10">
      <div class="card-header border-0">
        <div class="card-title m-0">
          <h3 class="fw-bolder m-0"><?=lang('profile_details')?></h3>
        </div>
      </div>
      <form action="" method="post">
        <div class="card-body border-top p-9">
          <div class="row mb-6">
            <label class="col-lg-4 col-form-label fw-bold fs-6"><?=lang('avatar')?></label>
            <div class="col-lg-8">
              <div class="image-input image-input-outline" data-kt-image-input="true">
                <div class="image-input-wrapper w-125px h-125px" style="background-image: url(<?=$profile_avatar;?>)"></div>
                <label class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow" data-kt-image-input-action="change" data-bs-toggle="tooltip" title="Change avatar">
                <i class="bi bi-pencil-fill fs-7"></i>
                <input type="file" name="avatar" accept=".png, .jpg, .jpeg">
                <input type="hidden" name="avatar_remove">
                </label>
                <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow" data-kt-image-input-action="cancel" data-bs-toggle="tooltip" title="Cancel avatar">
                <i class="bi bi-x fs-2"></i>
                </span>
              </div>
              <div class="form-text"><?=lang('allowed_files_thumbnail')?></div>
            </div>
          </div>
          <div class="row mb-6">
            <label class="col-lg-4 col-form-label fw-bold fs-6"><?=lang('full_name')?></label>
            <div class="col-lg-8 fv-row fv-plugins-icon-container">
              <input type="text" name="full_name" class="form-control form-control-lg form-control-solid" placeholder="Full Name" value="<?=$profile_fullname;?>">
            </div>
          </div>
		  <div class="row mb-6">
            <label class="col-lg-4 col-form-label fw-bold fs-6"><?=lang('username')?></label>
            <div class="col-lg-8 fv-row fv-plugins-icon-container">
              <input type="text" name="username" class="form-control form-control-lg form-control-solid" value="<?=$profile_name;?>" disabled>
            </div>
          </div>
          <div class="row mb-6">
            <label class="col-lg-4 col-form-label fw-bold fs-6"><?=lang('user_title')?></label>
            <div class="col-lg-8 fv-row fv-plugins-icon-container">
              <input type="text" name="user_title" class="form-control form-control-lg form-control-solid" placeholder="User Title" value="<?=$profile_title;?>">
            </div>
          </div>
          <div class="row mb-6">
            <label class="col-lg-4 col-form-label fw-bold fs-6"><?=lang('gender')?></label>
            <div class="col-lg-8 fv-row fv-plugins-icon-container">
              <select class="form-select form-select-lg mb-3" name="gender">
                <option selected disabled hidden>Choose...</option>
                <option value="Male" <?=$profile_gender == "Male" ? "selected" : "" ?>>Male</option>
                <option value="Female" <?=$profile_gender == "Female" ? "selected" : "" ?>>Female</option>
              </select>
            </div>
          </div>
          <div class="row mb-6">
            <label class="col-lg-4 col-form-label fw-bold fs-6"><?=lang('country')?></label>
            <div class="col-lg-8 fv-row fv-plugins-icon-container">
              <input type="text" name="country" class="form-control form-control-lg form-control-solid" placeholder="Country" value="<?=$profile_country;?>">
            </div>
          </div>
          <div class="row mb-6">
            <label class="col-lg-4 col-form-label fw-bold fs-6"><?=lang('website')?></label>
            <div class="col-lg-8 fv-row fv-plugins-icon-container">
              <input type="text" name="website" class="form-control form-control-lg form-control-solid" placeholder="Website" value="<?=$profile_website;?>">
            </div>
          </div>
		  <div class="row mb-6">
            <label class="col-lg-4 col-form-label fw-bold fs-6"><?=lang('bio')?></label>
            <div class="col-lg-8 fv-row fv-plugins-icon-container">
              <textarea class="form-control" name="bio" placeholder="Bio" rows="4" id="settings_bio" maxlength="<?=$bio_max_length;?>"><?=$profile_bio;?></textarea>
            </div>
          </div>
        </div>
        <div class="card-footer d-flex justify-content-end py-6 px-9">
          <button type="submit" class="btn btn-primary"><?=lang('save_changes');?></button>
        </div>
      </form>
    </div>
    <div class="card mb-5 mb-xl-10">
      <div class="card-header border-0">
        <div class="card-title m-0"><h3 class="fw-bolder m-0"><?=lang('security')?></h3></div>
      </div>
      <div id="kt_account_settings_signin_method" class="collapse show">
        <div class="card-body border-top p-9">
          <div class="d-flex flex-wrap align-items-center">
            <div id="kt_signin_email">
              <div class="fs-6 fw-bolder mb-1"><?=lang('email_add');?></div>
              <div class="fw-bold text-gray-600"><?=$profile_email;?></div>
            </div>
            <div id="kt_signin_email_edit" class="flex-row-fluid d-none">
              <form id="kt_signin_change_email" class="form fv-plugins-bootstrap5 fv-plugins-framework" novalidate="novalidate" action="" method="post">
                <div class="row mb-6">
                  <div class="col-lg-6 mb-4 mb-lg-0">
                    <div class="fv-row mb-0 fv-plugins-icon-container">
                      <label for="emailaddress" class="form-label fs-6 fw-bolder mb-3"><?=lang('enter_new_email')?></label>
                      <input type="email" class="form-control form-control-lg form-control-solid" id="emailaddress" placeholder="Email Address" name="emailaddress">
                      <div class="fv-plugins-message-container invalid-feedback"><?=$newEmailError;?></div>
                    </div>
                  </div>
                  <div class="col-lg-6">
                    <div class="fv-row mb-0 fv-plugins-icon-container">
                      <label for="confirmemailpassword" class="form-label fs-6 fw-bolder mb-3"><?=lang('confirm_password')?></label>
                      <input type="password" class="form-control form-control-lg form-control-solid" name="confirmemailpassword" id="confirmemailpassword">
                      <div class="fv-plugins-message-container invalid-feedback"><?=$confirmEmailPasswordError;?></div>
                    </div>
                  </div>
                </div>
                <div class="d-flex">
                  <button id="kt_signin_submit" type="button" class="btn btn-primary me-2 px-6"><?=lang('update_email')?></button>
                  <button id="kt_signin_cancel" type="button" class="btn btn-color-gray-400 btn-active-light-success px-6"><?=lang('cancel')?></button>
                </div>
                <div></div>
              </form>
            </div>
            <div id="kt_signin_email_button" class="ms-auto">
              <button class="btn btn-light btn-active-light-success"><?=lang('change_email')?></button>
            </div>
          </div>
		  
          <div class="separator separator-dashed my-6"></div>

          <div class="d-flex flex-wrap align-items-center mb-10">
            <div id="kt_signin_password">
              <div class="fs-6 fw-bolder mb-1"><?=lang('password')?></div>
              <div class="fw-bold text-gray-600">************</div>
            </div>

            <div id="kt_signin_password_edit" class="flex-row-fluid d-none">
              <form id="kt_signin_change_password" class="form fv-plugins-bootstrap5 fv-plugins-framework" novalidate="novalidate" action="" method="post">
                <div class="row mb-1">
                  <div class="col-lg-4">
                    <div class="fv-row mb-0 fv-plugins-icon-container">
                      <label for="currentpassword" class="form-label fs-6 fw-bolder mb-3"><?=lang('current_password')?></label>
                      <input type="password" class="form-control form-control-lg form-control-solid" name="currentpassword" id="currentpassword">
                      <div class="fv-plugins-message-container invalid-feedback"></div>
                    </div>
                  </div>
                  <div class="col-lg-4">
                    <div class="fv-row mb-0 fv-plugins-icon-container">
                      <label for="newpassword" class="form-label fs-6 fw-bolder mb-3"><?=lang('new_password')?></label>
                      <input type="password" class="form-control form-control-lg form-control-solid" name="newpassword" id="newpassword">
                      <div class="fv-plugins-message-container invalid-feedback"></div>
                    </div>
                  </div>
                  <div class="col-lg-4">
                    <div class="fv-row mb-0 fv-plugins-icon-container">
                      <label for="confirmpassword" class="form-label fs-6 fw-bolder mb-3"><?=lang('confirm_new_password')?></label>
                      <input type="password" class="form-control form-control-lg form-control-solid" name="confirmpassword" id="confirmpassword">
                      <div class="fv-plugins-message-container invalid-feedback"></div>
                    </div>
                  </div>
                </div>
                <div class="form-text mb-5">Password must be at least <?=$password_min_length;?> character and contain symbols</div>
                <div class="d-flex">
                  <button id="kt_password_submit" type="button" class="btn btn-primary me-2 px-6"><?=lang('update_password')?></button>
                  <button id="kt_password_cancel" type="button" class="btn btn-color-gray-400 btn-active-light-success px-6"><?=lang('cancel')?></button>
                </div>
                <div></div>
              </form>
            </div>
            <div id="kt_signin_password_button" class="ms-auto">
              <button class="btn btn-light btn-active-light-success"><?=lang('change_password')?></button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>