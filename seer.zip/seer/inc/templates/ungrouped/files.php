<div class="card card-docs mb-2 mt-5">
  <div class="card-body fs-6 py-15 px-10 py-lg-15 px-lg-15 text-gray-700">
    <div class="pb-10">
      <div class="py-5">Seer comes with a flexible file structure that can be easily used for small to large scope project. This section will explain the entire file structure and how to adapt it</div>
      <div class="pt-5">
        <div class="table-responsive border rounded">
          <table class="table table-striped table-flush align-middle mb-0">
            <thead>
              <tr class="fs-4 fw-bolder text-dark p-6">
                <th class="min-w-400px">File/Folder</th>
                <th class="min-w-500px">Description</th>
              </tr>
            </thead>
            <tbody>
              <tr class="p-6">
                <td>
                  <code>seer</code>
                </td>
                <td>The main theme folder.</td>
              </tr>
			  <tr class="p-6">
                <td class="ps-13">
                  <code>uploads</code>
                </td>
                <td>this is where all files and images that are uploaded by the users will be moved here</td>
              </tr>
			  <tr class="p-6">
                <td class="ps-13">
                  <code>assets</code>
                </td>
                <td>The source folder that contains of the CSS, Javascript and media files</td>
              </tr>
			  <tr class="p-6">
                <td class="ps-20">
                  <code>css</code>
                </td>
                <td>this folder contains the CSS code used to style the entire website</td>
              </tr>
			  <tr class="p-6">
                <td class="ps-20">
                  <code>js</code>
                </td>
                <td>this folder contains components written in Javascript</td>
              </tr>
			  <tr class="p-6">
                <td class="ps-20">
                  <code>images</code>
                </td>
                <td>this folder contains all the images that are used on the website</td>
              </tr>
			  <tr class="p-6">
                <td class="ps-20">
                  <code>plugins</code>
                </td>
                <td>The source folder that contains all the <a href="documentation.php?references" target="_blank">plugins</a> we used</td>
              </tr>
			  <tr class="p-6">
                <td class="ps-13">
                  <code>inc</code>
                </td>
                <td>The destination folder that contains the settings, config, templates and functions</td>
              </tr>
			  <tr class="p-6">
                <td class="ps-20">
                  <code>functions</code>
                </td>
                <td>functions prepared from scratch to reveal the best practices utilizing Seer</td>
              </tr>
			  <tr class="p-6">
                <td class="ps-20">
                  <code>templates</code>
                </td>
                <td>the main theme folder. templates provide initial code and formatting and to help seer to organize the project, make the development process easier and readable</td>
              </tr>
			  <tr class="p-6">
                <td class="ps-20">
                  <code>settings.php</code>
                </td>
                <td>The settings.php file is made to empower seer project, so you do not have to edit the functions and template files. All these settings can be overridden by your own customization and settings</td>
              </tr>
			  <tr class="p-6">
                <td class="ps-20">
                  <code>config.php</code>
                </td>
                <td>The config.php file is simple but elegant way is to connect to any database of your choice</td>
              </tr>
			  <tr class="p-6">
                <td class="ps-13">
                  <code>README.txt</code>
                </td>
                <td>A tiny help file that privides a quick guide to get started with Seer</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>