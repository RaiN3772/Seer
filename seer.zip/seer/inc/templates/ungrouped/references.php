<div class="docs-content d-flex flex-column flex-column-fluid mt-5" id="kt_docs_content">
  <div class="container" id="kt_docs_content_container">
    <div class="card card-docs mb-2">
      <div class="card-body fs-6 py-15 px-10 py-lg-15 px-lg-15 text-gray-700">
        <div class="p-0">
          <h1 class="anchor fw-bolder mb-5">References</h1>
          <div class="py-5">Seer uses the following open source resources:</div>
          <div class="py-5">
            <div class="table-responsive border rounded">
              <table class="table table-striped table-flush align-middle mb-0">
                <thead>
                  <tr class="fs-4 fw-bolder text-dark p-6">
                    <th class="min-w-400px">Name</th>
                    <th class="min-w-400px">Link</th>
                    <th class="min-w-100px">Version</th>
                  </tr>
                </thead>
                <tbody>
                  <tr class="p-6">
                    <td>
                      <code>FormValidation</code>
                    </td>
                    <td>
                      <a href="https://formvalidation.io/" target="_blank">https://formvalidation.io/</a>
                    </td>
                    <td>v1.8.0</td>
                  </tr>
                  <tr class="p-6">
                    <td>
                      <code>toastr</code>
                    </td>
                    <td>
                      <a href="https://github.com/petekeller2/toastr" target="_blank">https://github.com/petekeller2/toastr</a>
                    </td>
                    <td>v2.1.4</td>
                  </tr>
                  <tr class="p-6">
                    <td>
                      <code>@fortawesome/fontawesome-free</code>
                    </td>
                    <td>
                      <a href="https://fontawesome.com" target="_blank">https://fontawesome.com</a>
                    </td>
                    <td>v5.15.4</td>
                  </tr>
                  <tr class="p-6">
                    <td>
                      <code>@popperjs/core</code>
                    </td>
                    <td>
                      <a href="https://popper.js.org" target="_blank">https://popper.js.org</a>
                    </td>
                    <td>v2.10.2</td>
                  </tr>
                  <tr class="p-6">
                    <td>
                      <code>acorn</code>
                    </td>
                    <td>
                      <a href="https://github.com/acornjs/acorn" target="_blank">https://github.com/acornjs/acorn</a>
                    </td>
                    <td>v8.6.0</td>
                  </tr>
                  <tr class="p-6">
                    <td>
                      <code>autosize</code>
                    </td>
                    <td>
                      <a href="http://www.jacklmoore.com/autosize" target="_blank">http://www.jacklmoore.com/autosize</a>
                    </td>
                    <td>v5.0.1</td>
                  </tr>
                  <tr class="p-6">
                    <td>
                      <code>bootstrap</code>
                    </td>
                    <td>
                      <a href="https://getbootstrap.com/" target="_blank">https://getbootstrap.com/</a>
                    </td>
                    <td>v5.1.3</td>
                  </tr>
                  <tr class="p-6">
                    <td>
                      <code>bootstrap-icons</code>
                    </td>
                    <td>
                      <a href="https://icons.getbootstrap.com/" target="_blank">https://icons.getbootstrap.com/</a>
                    </td>
                    <td>v1.7.1</td>
                  </tr>
                  <tr class="p-6">
                    <td>
                      <code>bootstrap-maxlength</code>
                    </td>
                    <td>
                      <a href="https://github.com/mimo84/bootstrap-maxlength" target="_blank">https://github.com/mimo84/bootstrap-maxlength</a>
                    </td>
                    <td>v1.10.1</td>
                  </tr>
                  <tr class="p-6">
                    <td>
                      <code>countup.js</code>
                    </td>
                    <td>
                      <a href="https://github.com/inorganik/countUp.js" target="_blank">https://github.com/inorganik/countUp.js</a>
                    </td>
                    <td>v2.0.8</td>
                  </tr>
                  <tr class="p-6">
                    <td>
                      <code>dropzone</code>
                    </td>
                    <td>
                      <a href="http://www.dropzonejs.com" target="_blank">http://www.dropzonejs.com</a>
                    </td>
                    <td>v5.9.3</td>
                  </tr>
                  <tr class="p-6">
                    <td>
                      <code>es6-shim</code>
                    </td>
                    <td>
                      <a href="https://github.com/paulmillr/es6-shim/" target="_blank">https://github.com/paulmillr/es6-shim/</a>
                    </td>
                    <td>v0.35.6</td>
                  </tr>
                  <tr class="p-6">
                    <td>
                      <code>fslightbox</code>
                    </td>
                    <td>
                      <a href="https://fslightbox.com" target="_blank">https://fslightbox.com</a>
                    </td>
                    <td>v3.3.0-2</td>
                  </tr>
                  <tr class="p-6">
                    <td>
                      <code>handlebars</code>
                    </td>
                    <td>
                      <a href="http://www.handlebarsjs.com/" target="_blank">http://www.handlebarsjs.com/</a>
                    </td>
                    <td>v4.7.7</td>
                  </tr>
                  <tr class="p-6">
                    <td>
                      <code>jquery</code>
                    </td>
                    <td>
                      <a href="https://jquery.com" target="_blank">https://jquery.com</a>
                    </td>
                    <td>v3.6.0</td>
                  </tr>
                  <tr class="p-6">
                    <td>
                      <code>prism-themes</code>
                    </td>
                    <td>
                      <a href="https://github.com/prismjs/prism-themes#readme" target="_blank">https://github.com/prismjs/prism-themes#readme</a>
                    </td>
                    <td>v1.9.0</td>
                  </tr>
                  <tr class="p-6">
                    <td>
                      <code>prismjs</code>
                    </td>
                    <td>
                      <a href="https://github.com/PrismJS/prism" target="_blank">https://github.com/PrismJS/prism</a>
                    </td>
                    <td>v1.25.0</td>
                  </tr>
                  <tr class="p-6">
                    <td>
                      <code>select2</code>
                    </td>
                    <td>
                      <a href="https://select2.org" target="_blank">https://select2.org</a>
                    </td>
                    <td>v4.1.0-rc.0</td>
                  </tr>
                  <tr class="p-6">
                    <td>
                      <code>smooth-scroll</code>
                    </td>
                    <td>
                      <a href="http://github.com/cferdinandi/smooth-scroll" target="_blank">http://github.com/cferdinandi/smooth-scroll</a>
                    </td>
                    <td>v16.1.3</td>
                  </tr>
                  <tr class="p-6">
                    <td>
                      <code>sweetalert2</code>
                    </td>
                    <td>
                      <a href="https://sweetalert2.github.io/" target="_blank">https://sweetalert2.github.io/</a>
                    </td>
                    <td>v11.2.1</td>
                  </tr>
                  <tr class="p-6">
                    <td>
                      <code>wnumb</code>
                    </td>
                    <td>
                      <a href="https://github.com/leongersen/wnumb" target="_blank">https://github.com/leongersen/wnumb</a>
                    </td>
                    <td>v1.2.0</td>
                  </tr>
                  <tr class="p-6">
                    <td>
                      <code>freepik</code>
                    </td>
                    <td>
                      <a href="https://www.freepik.com" target="_blank">https://www.freepik.com</a>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>