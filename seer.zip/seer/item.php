<?php
  require_once 'inc/settings.php';
  require_once 'inc/language.php';
  
  include 'inc/svg.php'; 
  include 'inc/functions/session.php';
  include 'inc/functions/items/items_getItem.php';
  include 'inc/functions/items/item_getFeedbacks.php';
  include 'inc/functions/items/item_PostReply.php';
  ?>
<!doctype html>
<html>
  <head>
    <title><?=$website_name;?> - <?=$item_name;?></title>
    <?php include 'inc/templates/header/headerinclude.php';?>
  </head>
  <body id="kt_body" class="header-fixed header-tablet-and-mobile-fixed">
    <div class="d-flex flex-column flex-root">
      <div class="page d-flex flex-row flex-column-fluid">
        <div class="wrapper d-flex flex-column flex-row-fluid" id="kt_wrapper">
          <?php 
		  include 'inc/templates/header/header.php';
          include 'inc/templates/items/item.php';
          include 'inc/templates/footer/footer.php';
		  ?>
        </div>
      </div>
    </div>
    <?php include 'inc/templates/footer/footerinclude.php';?>
	<script>
$('#feedback').maxlength({
	alwaysShow: true,
	threshold: <?=$feedback_min_length;?>,
    warningClass: "badge badge-warning",
    limitReachedClass: "badge badge-success",
	validate: true
});
</script>
  </body>
</html>