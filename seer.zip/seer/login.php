<?php
  require_once 'inc/settings.php'; 
  require_once 'inc/language.php'; 
  
  include 'inc/functions/login.php';
?>
<!doctype html>  
<html>
  <head>
    <title><?=$website_name;?> - Login</title>
    <?php include 'inc/templates/header/headerinclude.php';?>
  </head>
  <body id="kt_body" class="header-fixed header-tablet-and-mobile-fixed">
    <div class="d-flex flex-column flex-root">
      <?php include 'inc/templates/login.php';?>
    </div>
    <?php include 'inc/templates/footer/footerinclude.php';?>
    <script src="assets/js/login.js"></script>
  </body>
</html>