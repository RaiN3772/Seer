<?php
// Start sessions
session_start();

// Destroy all session related to user
session_destroy();

sleep(2);

// Redirect to index page
header('location: index.php');
exit;

?>
