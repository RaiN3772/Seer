<?php
  require_once 'inc/settings.php';
  require_once 'inc/language.php';
  
  include 'inc/svg.php'; 
  include 'inc/functions/session.php';
  include 'inc/functions/profile/profile_getProfile.php';
  include 'inc/functions/profile/profile_getItems.php';
  include 'inc/functions/profile/profile_getTotalFeedbacks.php';

  ?>
<!doctype html>
<html>
  <head>
    <title><?=$website_name;?> - <?=$profile_name;?></title>
    <?php include 'inc/templates/header/headerinclude.php';?>
  </head>
  <body id="kt_body" class="header-fixed header-tablet-and-mobile-fixed">
    <div class="d-flex flex-column flex-root">
      <div class="page d-flex flex-row flex-column-fluid">
        <div class="wrapper d-flex flex-column flex-row-fluid" id="kt_wrapper">
          <?php 
		  include 'inc/templates/header/header.php';
          if ($private_profile == 1 && !isset($_SESSION["loggedin"])){ include 'inc/templates/profile/profile_accessDenied.php'; }
		  else { include 'inc/templates/profile/profile.php'; }
          include 'inc/templates/footer/footer.php';
		  ?>
        </div>
      </div>
    </div>
    <?php include 'inc/templates/footer/footerinclude.php';?>
  </body>
</html>