<?php
  require_once 'inc/settings.php';
  require_once 'inc/language.php';
  
  include 'inc/svg.php'; 
  include 'inc/functions/session.php';
  include 'inc/functions/profile/settings.php';
  include 'inc/functions/profile/settings_profileDetails.php';
  include 'inc/functions/profile/settings_changeEmail.php';
  include 'inc/functions/profile/settings_changepassword.php';
  ?>
<!doctype html>
<html>
  <head>
    <title><?=$website_name;?> - <?=$profile_name;?></title>
    <?php include 'inc/templates/header/headerinclude.php';?>
  </head>
  <body id="kt_body" class="header-fixed header-tablet-and-mobile-fixed">
    <div class="d-flex flex-column flex-root">
      <div class="page d-flex flex-row flex-column-fluid">
        <div class="wrapper d-flex flex-column flex-row-fluid" id="kt_wrapper">
          <?php 
		  include 'inc/templates/header/header.php';
          include 'inc/templates/profile/settings.php';
          include 'inc/templates/footer/footer.php';
		  ?>
        </div>
      </div>
    </div>
    <?php include 'inc/templates/footer/footerinclude.php';?>
	<script src="assets/js/profile_security.js"></script>
	<script>
	$('#settings_bio').maxlength({
    warningClass: "badge badge-success",
    limitReachedClass: "badge badge-danger"
});
	</script>
  </body>
</html>