<?php
  require_once 'inc/settings.php';
  require_once 'inc/language.php';
  
  include 'inc/functions/session.php';
  include 'inc/functions/items/upload_getCategories.php';
  include 'inc/functions/items/upload_item.php';
  include 'inc/svg.php';
?>
<!doctype html>
<html>
  <head>
    <title><?=$website_name;?> - Upload Item</title>
    <?php include 'inc/templates/header/headerinclude.php';?>
  </head>
  <body id="kt_body" class="header-fixed header-tablet-and-mobile-fixed">
    <div class="d-flex flex-column flex-root">
      <div class="page d-flex flex-row flex-column-fluid">
        <div class="wrapper d-flex flex-column flex-row-fluid" id="kt_wrapper">
          <?php include 'inc/templates/header/header.php';?>
          <div class="d-flex flex-column-fluid align-items-start container-xxl">
            <div class="content flex-row-fluid" id="kt_content">
              <?php
                if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) { 
					include 'inc/templates/items/upload_item_block.php';
                }
                else {
					include 'inc/templates/items/upload_item_login.php';
                }
                ?>
            </div>
          </div>
          <?php include 'inc/templates/footer/footer.php';?>
        </div>
      </div>
    </div>
    <?php include 'inc/templates/footer/footerinclude.php';?>
    <script src="assets/js/upload_item.js"></script>
  </body>
</html>
<?=$uid;?>